# ************************************************************
# Sequel Pro SQL dump
# Version 5446
#
# https://www.sequelpro.com/
# https://github.com/sequelpro/sequelpro
#
# Host: 127.0.0.1 (MySQL 5.7.29)
# Database: wordpress
# Generation Time: 2020-07-23 07:48:26 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
SET NAMES utf8mb4;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table wp_commentmeta
# ------------------------------------------------------------

DROP TABLE IF EXISTS `wp_commentmeta`;

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



# Dump of table wp_comments
# ------------------------------------------------------------

DROP TABLE IF EXISTS `wp_comments`;

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

LOCK TABLES `wp_comments` WRITE;
/*!40000 ALTER TABLE `wp_comments` DISABLE KEYS */;

INSERT INTO `wp_comments` (`comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`)
VALUES
	(1,1,'Een WordPress commentator','wapuu@wordpress.example','https://wordpress.org/','','2020-07-15 12:04:58','2020-07-15 12:04:58','Hoi, dit is een reactie.\nOm te beginnen met beheren, bewerken en verwijderen van reacties, ga je naar het Reacties scherm op het dashboard.\nAvatars van auteurs komen van <a href=\"https://gravatar.com\">Gravatar</a>.',0,'1','','',0,0);

/*!40000 ALTER TABLE `wp_comments` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table wp_links
# ------------------------------------------------------------

DROP TABLE IF EXISTS `wp_links`;

CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



# Dump of table wp_options
# ------------------------------------------------------------

DROP TABLE IF EXISTS `wp_options`;

CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`),
  KEY `autoload` (`autoload`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

LOCK TABLES `wp_options` WRITE;
/*!40000 ALTER TABLE `wp_options` DISABLE KEYS */;

INSERT INTO `wp_options` (`option_id`, `option_name`, `option_value`, `autoload`)
VALUES
	(3,'siteurl','https://headless-wordpress.lndo.site/wp','yes'),
	(4,'home','https://headless-wordpress.lndo.site/wp','yes'),
	(5,'blogname','NextPress','yes'),
	(6,'blogdescription','Ik ben een site','yes'),
	(7,'users_can_register','0','yes'),
	(8,'admin_email','hallo@trendwerk.nl','yes'),
	(9,'start_of_week','1','yes'),
	(10,'use_balanceTags','0','yes'),
	(11,'use_smilies','1','yes'),
	(12,'require_name_email','1','yes'),
	(13,'comments_notify','1','yes'),
	(14,'posts_per_rss','10','yes'),
	(15,'rss_use_excerpt','0','yes'),
	(16,'mailserver_url','mail.example.com','yes'),
	(17,'mailserver_login','login@example.com','yes'),
	(18,'mailserver_pass','password','yes'),
	(19,'mailserver_port','110','yes'),
	(20,'default_category','1','yes'),
	(21,'default_comment_status','open','yes'),
	(22,'default_ping_status','open','yes'),
	(23,'default_pingback_flag','1','yes'),
	(24,'posts_per_page','10','yes'),
	(25,'date_format','j F Y','yes'),
	(26,'time_format','H:i','yes'),
	(27,'links_updated_date_format','j F Y H:i','yes'),
	(28,'comment_moderation','0','yes'),
	(29,'moderation_notify','1','yes'),
	(30,'permalink_structure','/%postname%/','yes'),
	(31,'rewrite_rules','a:89:{s:11:\"^wp-json/?$\";s:22:\"index.php?rest_route=/\";s:14:\"^wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:21:\"^index.php/wp-json/?$\";s:22:\"index.php?rest_route=/\";s:24:\"^index.php/wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:10:\"graphql/?$\";s:22:\"index.php?graphql=true\";s:47:\"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:42:\"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:23:\"category/(.+?)/embed/?$\";s:46:\"index.php?category_name=$matches[1]&embed=true\";s:35:\"category/(.+?)/page/?([0-9]{1,})/?$\";s:53:\"index.php?category_name=$matches[1]&paged=$matches[2]\";s:17:\"category/(.+?)/?$\";s:35:\"index.php?category_name=$matches[1]\";s:44:\"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:39:\"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:20:\"tag/([^/]+)/embed/?$\";s:36:\"index.php?tag=$matches[1]&embed=true\";s:32:\"tag/([^/]+)/page/?([0-9]{1,})/?$\";s:43:\"index.php?tag=$matches[1]&paged=$matches[2]\";s:14:\"tag/([^/]+)/?$\";s:25:\"index.php?tag=$matches[1]\";s:45:\"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:40:\"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:21:\"type/([^/]+)/embed/?$\";s:44:\"index.php?post_format=$matches[1]&embed=true\";s:33:\"type/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?post_format=$matches[1]&paged=$matches[2]\";s:15:\"type/([^/]+)/?$\";s:33:\"index.php?post_format=$matches[1]\";s:12:\"robots\\.txt$\";s:18:\"index.php?robots=1\";s:13:\"favicon\\.ico$\";s:19:\"index.php?favicon=1\";s:48:\".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$\";s:18:\"index.php?feed=old\";s:20:\".*wp-app\\.php(/.*)?$\";s:19:\"index.php?error=403\";s:18:\".*wp-register.php$\";s:23:\"index.php?register=true\";s:32:\"feed/(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:27:\"(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:8:\"embed/?$\";s:21:\"index.php?&embed=true\";s:20:\"page/?([0-9]{1,})/?$\";s:28:\"index.php?&paged=$matches[1]\";s:41:\"comments/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:36:\"comments/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:17:\"comments/embed/?$\";s:21:\"index.php?&embed=true\";s:44:\"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:39:\"search/(.+)/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:20:\"search/(.+)/embed/?$\";s:34:\"index.php?s=$matches[1]&embed=true\";s:32:\"search/(.+)/page/?([0-9]{1,})/?$\";s:41:\"index.php?s=$matches[1]&paged=$matches[2]\";s:14:\"search/(.+)/?$\";s:23:\"index.php?s=$matches[1]\";s:47:\"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:42:\"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:23:\"author/([^/]+)/embed/?$\";s:44:\"index.php?author_name=$matches[1]&embed=true\";s:35:\"author/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?author_name=$matches[1]&paged=$matches[2]\";s:17:\"author/([^/]+)/?$\";s:33:\"index.php?author_name=$matches[1]\";s:69:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:45:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$\";s:74:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]\";s:39:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$\";s:63:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]\";s:56:\"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:51:\"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:32:\"([0-9]{4})/([0-9]{1,2})/embed/?$\";s:58:\"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true\";s:44:\"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]\";s:26:\"([0-9]{4})/([0-9]{1,2})/?$\";s:47:\"index.php?year=$matches[1]&monthnum=$matches[2]\";s:43:\"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:38:\"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:19:\"([0-9]{4})/embed/?$\";s:37:\"index.php?year=$matches[1]&embed=true\";s:31:\"([0-9]{4})/page/?([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&paged=$matches[2]\";s:13:\"([0-9]{4})/?$\";s:26:\"index.php?year=$matches[1]\";s:27:\".?.+?/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\".?.+?/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:33:\".?.+?/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:16:\"(.?.+?)/embed/?$\";s:41:\"index.php?pagename=$matches[1]&embed=true\";s:20:\"(.?.+?)/trackback/?$\";s:35:\"index.php?pagename=$matches[1]&tb=1\";s:40:\"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:35:\"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:28:\"(.?.+?)/page/?([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&paged=$matches[2]\";s:35:\"(.?.+?)/comment-page-([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&cpage=$matches[2]\";s:24:\"(.?.+?)(?:/([0-9]+))?/?$\";s:47:\"index.php?pagename=$matches[1]&page=$matches[2]\";s:27:\"[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\"[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:33:\"[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:16:\"([^/]+)/embed/?$\";s:37:\"index.php?name=$matches[1]&embed=true\";s:20:\"([^/]+)/trackback/?$\";s:31:\"index.php?name=$matches[1]&tb=1\";s:40:\"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?name=$matches[1]&feed=$matches[2]\";s:35:\"([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?name=$matches[1]&feed=$matches[2]\";s:28:\"([^/]+)/page/?([0-9]{1,})/?$\";s:44:\"index.php?name=$matches[1]&paged=$matches[2]\";s:35:\"([^/]+)/comment-page-([0-9]{1,})/?$\";s:44:\"index.php?name=$matches[1]&cpage=$matches[2]\";s:24:\"([^/]+)(?:/([0-9]+))?/?$\";s:43:\"index.php?name=$matches[1]&page=$matches[2]\";s:16:\"[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:26:\"[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:46:\"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:41:\"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:41:\"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:22:\"[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";}','yes'),
	(32,'hack_file','0','yes'),
	(33,'blog_charset','UTF-8','yes'),
	(34,'moderation_keys','','no'),
	(35,'active_plugins','a:5:{i:0;s:34:\"advanced-custom-fields-pro/acf.php\";i:1;s:45:\"limit-login-attempts/limit-login-attempts.php\";i:2;s:27:\"wp-graphiql/wp-graphiql.php\";i:3;s:33:\"wp-graphql-acf/wp-graphql-acf.php\";i:5;s:25:\"wp-graphql/wp-graphql.php\";}','yes'),
	(36,'category_base','','yes'),
	(37,'ping_sites','http://rpc.pingomatic.com/','yes'),
	(38,'comment_max_links','2','yes'),
	(39,'gmt_offset','0','yes'),
	(40,'default_email_category','1','yes'),
	(41,'recently_edited','','no'),
	(42,'template','headless','yes'),
	(43,'stylesheet','headless','yes'),
	(44,'comment_whitelist','1','yes'),
	(45,'blacklist_keys','','no'),
	(46,'comment_registration','0','yes'),
	(47,'html_type','text/html','yes'),
	(48,'use_trackback','0','yes'),
	(49,'default_role','subscriber','yes'),
	(50,'db_version','47018','yes'),
	(51,'uploads_use_yearmonth_folders','1','yes'),
	(52,'upload_path','','yes'),
	(53,'blog_public','1','yes'),
	(54,'default_link_category','2','yes'),
	(55,'show_on_front','posts','yes'),
	(56,'tag_base','','yes'),
	(57,'show_avatars','1','yes'),
	(58,'avatar_rating','G','yes'),
	(59,'upload_url_path','','yes'),
	(60,'thumbnail_size_w','150','yes'),
	(61,'thumbnail_size_h','150','yes'),
	(62,'thumbnail_crop','1','yes'),
	(63,'medium_size_w','300','yes'),
	(64,'medium_size_h','300','yes'),
	(65,'avatar_default','mystery','yes'),
	(66,'large_size_w','1024','yes'),
	(67,'large_size_h','1024','yes'),
	(68,'image_default_link_type','none','yes'),
	(69,'image_default_size','','yes'),
	(70,'image_default_align','','yes'),
	(71,'close_comments_for_old_posts','0','yes'),
	(72,'close_comments_days_old','14','yes'),
	(73,'thread_comments','1','yes'),
	(74,'thread_comments_depth','5','yes'),
	(75,'page_comments','0','yes'),
	(76,'comments_per_page','50','yes'),
	(77,'default_comments_page','newest','yes'),
	(78,'comment_order','asc','yes'),
	(79,'sticky_posts','a:0:{}','yes'),
	(80,'widget_categories','a:2:{i:2;a:4:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:12:\"hierarchical\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}','yes'),
	(81,'widget_text','a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}','yes'),
	(82,'widget_rss','a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}','yes'),
	(83,'uninstall_plugins','a:0:{}','no'),
	(84,'timezone_string','','yes'),
	(85,'page_for_posts','0','yes'),
	(86,'page_on_front','0','yes'),
	(87,'default_post_format','0','yes'),
	(88,'link_manager_enabled','0','yes'),
	(89,'finished_splitting_shared_terms','1','yes'),
	(90,'site_icon','0','yes'),
	(91,'medium_large_size_w','768','yes'),
	(92,'medium_large_size_h','0','yes'),
	(93,'wp_page_for_privacy_policy','3','yes'),
	(94,'show_comments_cookies_opt_in','1','yes'),
	(95,'admin_email_lifespan','1610366698','yes'),
	(96,'initial_db_version','47018','yes'),
	(97,'wp_user_roles','a:5:{s:13:\"administrator\";a:2:{s:4:\"name\";s:13:\"Administrator\";s:12:\"capabilities\";a:61:{s:13:\"switch_themes\";b:1;s:11:\"edit_themes\";b:1;s:16:\"activate_plugins\";b:1;s:12:\"edit_plugins\";b:1;s:10:\"edit_users\";b:1;s:10:\"edit_files\";b:1;s:14:\"manage_options\";b:1;s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:6:\"import\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:8:\"level_10\";b:1;s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:12:\"delete_users\";b:1;s:12:\"create_users\";b:1;s:17:\"unfiltered_upload\";b:1;s:14:\"edit_dashboard\";b:1;s:14:\"update_plugins\";b:1;s:14:\"delete_plugins\";b:1;s:15:\"install_plugins\";b:1;s:13:\"update_themes\";b:1;s:14:\"install_themes\";b:1;s:11:\"update_core\";b:1;s:10:\"list_users\";b:1;s:12:\"remove_users\";b:1;s:13:\"promote_users\";b:1;s:18:\"edit_theme_options\";b:1;s:13:\"delete_themes\";b:1;s:6:\"export\";b:1;}}s:6:\"editor\";a:2:{s:4:\"name\";s:6:\"Editor\";s:12:\"capabilities\";a:34:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;}}s:6:\"author\";a:2:{s:4:\"name\";s:6:\"Author\";s:12:\"capabilities\";a:10:{s:12:\"upload_files\";b:1;s:10:\"edit_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;s:22:\"delete_published_posts\";b:1;}}s:11:\"contributor\";a:2:{s:4:\"name\";s:11:\"Contributor\";s:12:\"capabilities\";a:5:{s:10:\"edit_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;}}s:10:\"subscriber\";a:2:{s:4:\"name\";s:10:\"Subscriber\";s:12:\"capabilities\";a:2:{s:4:\"read\";b:1;s:7:\"level_0\";b:1;}}}','yes'),
	(98,'fresh_site','0','yes'),
	(99,'WPLANG','nl_NL','yes'),
	(100,'widget_search','a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}','yes'),
	(101,'widget_recent-posts','a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}','yes'),
	(102,'widget_recent-comments','a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}','yes'),
	(103,'widget_archives','a:2:{i:2;a:3:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}','yes'),
	(104,'widget_meta','a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}','yes'),
	(105,'sidebars_widgets','a:2:{s:19:\"wp_inactive_widgets\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}s:13:\"array_version\";i:3;}','yes'),
	(106,'bedrock_autoloader','a:2:{s:7:\"plugins\";a:0:{}s:5:\"count\";i:0;}','no'),
	(107,'cron','a:5:{i:1595491499;a:1:{s:34:\"wp_privacy_delete_old_export_files\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1595505899;a:5:{s:30:\"wp_site_health_scheduled_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"weekly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:604800;}}s:32:\"recovery_mode_clean_expired_keys\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:16:\"wp_version_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:17:\"wp_update_plugins\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:16:\"wp_update_themes\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1595505906;a:2:{s:19:\"wp_scheduled_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:25:\"delete_expired_transients\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1595505907;a:1:{s:30:\"wp_scheduled_auto_draft_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}s:7:\"version\";i:2;}','yes'),
	(108,'widget_pages','a:1:{s:12:\"_multiwidget\";i:1;}','yes'),
	(109,'widget_calendar','a:1:{s:12:\"_multiwidget\";i:1;}','yes'),
	(110,'widget_media_audio','a:1:{s:12:\"_multiwidget\";i:1;}','yes'),
	(111,'widget_media_image','a:1:{s:12:\"_multiwidget\";i:1;}','yes'),
	(112,'widget_media_gallery','a:1:{s:12:\"_multiwidget\";i:1;}','yes'),
	(113,'widget_media_video','a:1:{s:12:\"_multiwidget\";i:1;}','yes'),
	(114,'widget_tag_cloud','a:1:{s:12:\"_multiwidget\";i:1;}','yes'),
	(115,'widget_nav_menu','a:1:{s:12:\"_multiwidget\";i:1;}','yes'),
	(116,'widget_custom_html','a:1:{s:12:\"_multiwidget\";i:1;}','yes'),
	(118,'recovery_keys','a:0:{}','yes'),
	(119,'_site_transient_update_core','O:8:\"stdClass\":4:{s:7:\"updates\";a:1:{i:0;O:8:\"stdClass\":10:{s:8:\"response\";s:6:\"latest\";s:8:\"download\";s:65:\"https://downloads.wordpress.org/release/nl_NL/wordpress-5.4.2.zip\";s:6:\"locale\";s:5:\"nl_NL\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:65:\"https://downloads.wordpress.org/release/nl_NL/wordpress-5.4.2.zip\";s:10:\"no_content\";b:0;s:11:\"new_bundled\";b:0;s:7:\"partial\";b:0;s:8:\"rollback\";b:0;}s:7:\"current\";s:5:\"5.4.2\";s:7:\"version\";s:5:\"5.4.2\";s:11:\"php_version\";s:6:\"5.6.20\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"5.3\";s:15:\"partial_version\";s:0:\"\";}}s:12:\"last_checked\";i:1595483128;s:15:\"version_checked\";s:5:\"5.4.2\";s:12:\"translations\";a:1:{i:0;a:7:{s:4:\"type\";s:4:\"core\";s:4:\"slug\";s:7:\"default\";s:8:\"language\";s:5:\"nl_NL\";s:7:\"version\";s:5:\"5.4.2\";s:7:\"updated\";s:19:\"2020-07-18 21:15:18\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.4.2/nl_NL.zip\";s:10:\"autoupdate\";b:1;}}}','no'),
	(120,'_site_transient_update_plugins','O:8:\"stdClass\":4:{s:12:\"last_checked\";i:1595483129;s:8:\"response\";a:0:{}s:12:\"translations\";a:1:{i:0;a:7:{s:4:\"type\";s:6:\"plugin\";s:4:\"slug\";s:20:\"limit-login-attempts\";s:8:\"language\";s:5:\"nl_NL\";s:7:\"version\";s:5:\"1.7.1\";s:7:\"updated\";s:19:\"2017-06-15 13:27:00\";s:7:\"package\";s:86:\"http://downloads.wordpress.org/translation/plugin/limit-login-attempts/1.7.1/nl_NL.zip\";s:10:\"autoupdate\";b:1;}}s:9:\"no_update\";a:1:{s:45:\"limit-login-attempts/limit-login-attempts.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:34:\"w.org/plugins/limit-login-attempts\";s:4:\"slug\";s:20:\"limit-login-attempts\";s:6:\"plugin\";s:45:\"limit-login-attempts/limit-login-attempts.php\";s:11:\"new_version\";s:5:\"1.7.1\";s:3:\"url\";s:51:\"https://wordpress.org/plugins/limit-login-attempts/\";s:7:\"package\";s:68:\"http://downloads.wordpress.org/plugin/limit-login-attempts.1.7.1.zip\";s:5:\"icons\";a:1:{s:7:\"default\";s:64:\"https://s.w.org/plugins/geopattern-icon/limit-login-attempts.svg\";}s:7:\"banners\";a:0:{}s:11:\"banners_rtl\";a:0:{}}}}','no'),
	(121,'theme_mods_twentytwenty','a:2:{s:18:\"custom_css_post_id\";i:-1;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1594816036;s:4:\"data\";a:3:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:3:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";}s:9:\"sidebar-2\";a:3:{i:0;s:10:\"archives-2\";i:1;s:12:\"categories-2\";i:2;s:6:\"meta-2\";}}}}','yes'),
	(122,'_site_transient_update_themes','O:8:\"stdClass\":4:{s:12:\"last_checked\";i:1595483135;s:7:\"checked\";a:11:{s:8:\"headless\";s:5:\"1.0.0\";s:12:\"twentyeleven\";s:3:\"3.4\";s:13:\"twentyfifteen\";s:3:\"2.6\";s:14:\"twentyfourteen\";s:3:\"2.8\";s:14:\"twentynineteen\";s:3:\"1.5\";s:15:\"twentyseventeen\";s:3:\"2.3\";s:13:\"twentysixteen\";s:3:\"2.1\";s:9:\"twentyten\";s:3:\"3.0\";s:14:\"twentythirteen\";s:3:\"3.0\";s:12:\"twentytwelve\";s:3:\"3.1\";s:12:\"twentytwenty\";s:3:\"1.2\";}s:8:\"response\";a:2:{s:14:\"twentynineteen\";a:6:{s:5:\"theme\";s:14:\"twentynineteen\";s:11:\"new_version\";s:3:\"1.6\";s:3:\"url\";s:44:\"https://wordpress.org/themes/twentynineteen/\";s:7:\"package\";s:60:\"https://downloads.wordpress.org/theme/twentynineteen.1.6.zip\";s:8:\"requires\";s:5:\"4.9.6\";s:12:\"requires_php\";s:5:\"5.2.4\";}s:12:\"twentytwenty\";a:6:{s:5:\"theme\";s:12:\"twentytwenty\";s:11:\"new_version\";s:3:\"1.4\";s:3:\"url\";s:42:\"https://wordpress.org/themes/twentytwenty/\";s:7:\"package\";s:58:\"https://downloads.wordpress.org/theme/twentytwenty.1.4.zip\";s:8:\"requires\";s:3:\"4.7\";s:12:\"requires_php\";s:5:\"5.2.4\";}}s:12:\"translations\";a:10:{i:0;a:7:{s:4:\"type\";s:5:\"theme\";s:4:\"slug\";s:12:\"twentyeleven\";s:8:\"language\";s:5:\"nl_NL\";s:7:\"version\";s:3:\"3.4\";s:7:\"updated\";s:19:\"2020-06-13 20:59:39\";s:7:\"package\";s:76:\"https://downloads.wordpress.org/translation/theme/twentyeleven/3.4/nl_NL.zip\";s:10:\"autoupdate\";b:1;}i:1;a:7:{s:4:\"type\";s:5:\"theme\";s:4:\"slug\";s:13:\"twentyfifteen\";s:8:\"language\";s:5:\"nl_NL\";s:7:\"version\";s:3:\"2.6\";s:7:\"updated\";s:19:\"2020-06-15 07:39:41\";s:7:\"package\";s:77:\"https://downloads.wordpress.org/translation/theme/twentyfifteen/2.6/nl_NL.zip\";s:10:\"autoupdate\";b:1;}i:2;a:7:{s:4:\"type\";s:5:\"theme\";s:4:\"slug\";s:14:\"twentyfourteen\";s:8:\"language\";s:5:\"nl_NL\";s:7:\"version\";s:3:\"2.8\";s:7:\"updated\";s:19:\"2020-06-13 20:57:39\";s:7:\"package\";s:78:\"https://downloads.wordpress.org/translation/theme/twentyfourteen/2.8/nl_NL.zip\";s:10:\"autoupdate\";b:1;}i:3;a:7:{s:4:\"type\";s:5:\"theme\";s:4:\"slug\";s:14:\"twentynineteen\";s:8:\"language\";s:5:\"nl_NL\";s:7:\"version\";s:3:\"1.5\";s:7:\"updated\";s:19:\"2020-06-06 21:11:04\";s:7:\"package\";s:78:\"https://downloads.wordpress.org/translation/theme/twentynineteen/1.5/nl_NL.zip\";s:10:\"autoupdate\";b:1;}i:4;a:7:{s:4:\"type\";s:5:\"theme\";s:4:\"slug\";s:15:\"twentyseventeen\";s:8:\"language\";s:5:\"nl_NL\";s:7:\"version\";s:3:\"2.3\";s:7:\"updated\";s:19:\"2020-06-06 21:09:16\";s:7:\"package\";s:79:\"https://downloads.wordpress.org/translation/theme/twentyseventeen/2.3/nl_NL.zip\";s:10:\"autoupdate\";b:1;}i:5;a:7:{s:4:\"type\";s:5:\"theme\";s:4:\"slug\";s:13:\"twentysixteen\";s:8:\"language\";s:5:\"nl_NL\";s:7:\"version\";s:3:\"2.1\";s:7:\"updated\";s:19:\"2019-02-18 14:56:08\";s:7:\"package\";s:77:\"https://downloads.wordpress.org/translation/theme/twentysixteen/2.1/nl_NL.zip\";s:10:\"autoupdate\";b:1;}i:6;a:7:{s:4:\"type\";s:5:\"theme\";s:4:\"slug\";s:9:\"twentyten\";s:8:\"language\";s:5:\"nl_NL\";s:7:\"version\";s:3:\"3.0\";s:7:\"updated\";s:19:\"2020-06-13 20:59:54\";s:7:\"package\";s:73:\"https://downloads.wordpress.org/translation/theme/twentyten/3.0/nl_NL.zip\";s:10:\"autoupdate\";b:1;}i:7;a:7:{s:4:\"type\";s:5:\"theme\";s:4:\"slug\";s:14:\"twentythirteen\";s:8:\"language\";s:5:\"nl_NL\";s:7:\"version\";s:3:\"3.0\";s:7:\"updated\";s:19:\"2020-06-13 20:56:53\";s:7:\"package\";s:78:\"https://downloads.wordpress.org/translation/theme/twentythirteen/3.0/nl_NL.zip\";s:10:\"autoupdate\";b:1;}i:8;a:7:{s:4:\"type\";s:5:\"theme\";s:4:\"slug\";s:12:\"twentytwelve\";s:8:\"language\";s:5:\"nl_NL\";s:7:\"version\";s:3:\"3.1\";s:7:\"updated\";s:19:\"2020-06-13 20:58:26\";s:7:\"package\";s:76:\"https://downloads.wordpress.org/translation/theme/twentytwelve/3.1/nl_NL.zip\";s:10:\"autoupdate\";b:1;}i:9;a:7:{s:4:\"type\";s:5:\"theme\";s:4:\"slug\";s:12:\"twentytwenty\";s:8:\"language\";s:5:\"nl_NL\";s:7:\"version\";s:3:\"1.2\";s:7:\"updated\";s:19:\"2019-12-14 14:55:12\";s:7:\"package\";s:76:\"https://downloads.wordpress.org/translation/theme/twentytwenty/1.2/nl_NL.zip\";s:10:\"autoupdate\";b:1;}}}','no'),
	(128,'can_compress_scripts','0','no'),
	(141,'recently_activated','a:1:{s:31:\"wp-graphql-gutenberg/plugin.php\";i:1595416295;}','yes'),
	(142,'acf_version','5.8.12','yes'),
	(143,'template_root','/themes','yes'),
	(144,'stylesheet_root','/themes','yes'),
	(145,'current_theme','Headless','yes'),
	(146,'theme_mods_headless','a:3:{i:0;b:0;s:18:\"nav_menu_locations\";a:2:{s:6:\"footer\";i:3;s:4:\"main\";i:2;}s:18:\"custom_css_post_id\";i:-1;}','yes'),
	(147,'theme_switched','','yes'),
	(173,'_transient_health-check-site-status-result','{\"good\":8,\"recommended\":8,\"critical\":1}','yes'),
	(206,'new_admin_email','hallo@trendwerk.nl','yes'),
	(245,'nav_menu_options','a:2:{i:0;b:0;s:8:\"auto_add\";a:0:{}}','yes'),
	(256,'_transient_timeout_acf_plugin_updates','1595582613','no'),
	(257,'_transient_acf_plugin_updates','a:4:{s:7:\"plugins\";a:0:{}s:10:\"expiration\";i:172800;s:6:\"status\";i:1;s:7:\"checked\";a:1:{s:34:\"advanced-custom-fields-pro/acf.php\";s:6:\"5.8.12\";}}','no'),
	(261,'_site_transient_timeout_browser_2956876d4fe349e43e23774e751b61f7','1596019038','no'),
	(262,'_site_transient_browser_2956876d4fe349e43e23774e751b61f7','a:10:{s:4:\"name\";s:6:\"Chrome\";s:7:\"version\";s:12:\"84.0.4147.89\";s:8:\"platform\";s:9:\"Macintosh\";s:10:\"update_url\";s:29:\"https://www.google.com/chrome\";s:7:\"img_src\";s:43:\"http://s.w.org/images/browsers/chrome.png?1\";s:11:\"img_src_ssl\";s:44:\"https://s.w.org/images/browsers/chrome.png?1\";s:15:\"current_version\";s:2:\"18\";s:7:\"upgrade\";b:0;s:8:\"insecure\";b:0;s:6:\"mobile\";b:0;}','no'),
	(271,'_site_transient_timeout_php_check_c60e90b5b23808bb6ae5fe6d44788a5f','1596034142','no'),
	(272,'_site_transient_php_check_c60e90b5b23808bb6ae5fe6d44788a5f','a:5:{s:19:\"recommended_version\";s:3:\"7.4\";s:15:\"minimum_version\";s:6:\"5.6.20\";s:12:\"is_supported\";b:1;s:9:\"is_secure\";b:1;s:13:\"is_acceptable\";b:1;}','no'),
	(277,'_site_transient_timeout_theme_roots','1595484934','no'),
	(278,'_site_transient_theme_roots','a:11:{s:8:\"headless\";s:7:\"/themes\";s:12:\"twentyeleven\";s:29:\"/app/web/wp/wp-content/themes\";s:13:\"twentyfifteen\";s:29:\"/app/web/wp/wp-content/themes\";s:14:\"twentyfourteen\";s:29:\"/app/web/wp/wp-content/themes\";s:14:\"twentynineteen\";s:29:\"/app/web/wp/wp-content/themes\";s:15:\"twentyseventeen\";s:29:\"/app/web/wp/wp-content/themes\";s:13:\"twentysixteen\";s:29:\"/app/web/wp/wp-content/themes\";s:9:\"twentyten\";s:29:\"/app/web/wp/wp-content/themes\";s:14:\"twentythirteen\";s:29:\"/app/web/wp/wp-content/themes\";s:12:\"twentytwelve\";s:29:\"/app/web/wp/wp-content/themes\";s:12:\"twentytwenty\";s:29:\"/app/web/wp/wp-content/themes\";}','no');

/*!40000 ALTER TABLE `wp_options` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table wp_postmeta
# ------------------------------------------------------------

DROP TABLE IF EXISTS `wp_postmeta`;

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

LOCK TABLES `wp_postmeta` WRITE;
/*!40000 ALTER TABLE `wp_postmeta` DISABLE KEYS */;

INSERT INTO `wp_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`)
VALUES
	(1,2,'_wp_page_template','default'),
	(2,3,'_wp_page_template','default'),
	(3,2,'_edit_lock','1595334151:1'),
	(4,7,'_edit_lock','1594840719:1'),
	(5,8,'_edit_lock','1594840930:1'),
	(8,3,'_edit_lock','1594989230:1'),
	(9,2,'_edit_last','1'),
	(10,2,'meta_description','Hoi daar! Ik ben een fietskoerier in het dagelijks leven en een beginnende acteur in de avonduren. Ik leef in Los Angeles, heb een leuke hond genaamd Jack en ik'),
	(11,2,'_meta_description','field_meta_description'),
	(12,10,'meta_description','Hoi daar! Ik ben een fietskoerier in het dagelijks leven en een beginnende acteur in de avonduren. Ik leef in Los Angeles, heb een leuke hond genaamd Jack en ik'),
	(13,10,'_meta_description','field_meta_description'),
	(14,2,'seo_title','Overschreven title'),
	(15,2,'_seo_title','field_seo_title'),
	(16,2,'seo_description','Duis mollis, est non commodo luctus, nisi erat porttitor ligula, eget lacinia odio sem nec elit. Vestibulum id ligula porta felis euismod semper.'),
	(17,2,'_seo_description','field_seo_description'),
	(18,10,'seo_title',''),
	(19,10,'_seo_title','field_seo_title'),
	(20,10,'seo_description',''),
	(21,10,'_seo_description','field_seo_description'),
	(22,11,'meta_description','Hoi daar! Ik ben een fietskoerier in het dagelijks leven en een beginnende acteur in de avonduren. Ik leef in Los Angeles, heb een leuke hond genaamd Jack en ik'),
	(23,11,'_meta_description','field_meta_description'),
	(24,11,'seo_title','Overschreven title'),
	(25,11,'_seo_title','field_seo_title'),
	(26,11,'seo_description','Duis mollis, est non commodo luctus, nisi erat porttitor ligula, eget lacinia odio sem nec elit. Vestibulum id ligula porta felis euismod semper.'),
	(27,11,'_seo_description','field_seo_description'),
	(28,3,'_edit_last','1'),
	(29,3,'seo_title',''),
	(30,3,'_seo_title','field_seo_title'),
	(31,3,'seo_description',''),
	(32,3,'_seo_description','field_seo_description'),
	(33,12,'seo_title',''),
	(34,12,'_seo_title','field_seo_title'),
	(35,12,'seo_description',''),
	(36,12,'_seo_description','field_seo_description'),
	(37,14,'_wp_attached_file','2020/07/luca-bravo-ESkw2ayO2As-unsplash-scaled.jpg'),
	(38,14,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:2560;s:6:\"height\";i:1767;s:4:\"file\";s:50:\"2020/07/luca-bravo-ESkw2ayO2As-unsplash-scaled.jpg\";s:5:\"sizes\";a:6:{s:6:\"medium\";a:4:{s:4:\"file\";s:43:\"luca-bravo-ESkw2ayO2As-unsplash-300x207.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:207;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:44:\"luca-bravo-ESkw2ayO2As-unsplash-1024x707.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:707;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:43:\"luca-bravo-ESkw2ayO2As-unsplash-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:43:\"luca-bravo-ESkw2ayO2As-unsplash-768x530.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:530;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:45:\"luca-bravo-ESkw2ayO2As-unsplash-1536x1060.jpg\";s:5:\"width\";i:1536;s:6:\"height\";i:1060;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"2048x2048\";a:4:{s:4:\"file\";s:45:\"luca-bravo-ESkw2ayO2As-unsplash-2048x1414.jpg\";s:5:\"width\";i:2048;s:6:\"height\";i:1414;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}s:14:\"original_image\";s:35:\"luca-bravo-ESkw2ayO2As-unsplash.jpg\";}'),
	(39,15,'_wp_attached_file','2020/07/luca-bravo-hFzIoD0F_i8-unsplash-scaled.jpg'),
	(40,15,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:2560;s:6:\"height\";i:1600;s:4:\"file\";s:50:\"2020/07/luca-bravo-hFzIoD0F_i8-unsplash-scaled.jpg\";s:5:\"sizes\";a:6:{s:6:\"medium\";a:4:{s:4:\"file\";s:43:\"luca-bravo-hFzIoD0F_i8-unsplash-300x188.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:188;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:44:\"luca-bravo-hFzIoD0F_i8-unsplash-1024x640.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:640;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:43:\"luca-bravo-hFzIoD0F_i8-unsplash-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:43:\"luca-bravo-hFzIoD0F_i8-unsplash-768x480.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:480;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:44:\"luca-bravo-hFzIoD0F_i8-unsplash-1536x960.jpg\";s:5:\"width\";i:1536;s:6:\"height\";i:960;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"2048x2048\";a:4:{s:4:\"file\";s:45:\"luca-bravo-hFzIoD0F_i8-unsplash-2048x1280.jpg\";s:5:\"width\";i:2048;s:6:\"height\";i:1280;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}s:14:\"original_image\";s:35:\"luca-bravo-hFzIoD0F_i8-unsplash.jpg\";}'),
	(41,16,'_wp_attached_file','2020/07/luca-bravo-O453M2Liufs-unsplash-scaled.jpg'),
	(42,16,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:2560;s:6:\"height\";i:1707;s:4:\"file\";s:50:\"2020/07/luca-bravo-O453M2Liufs-unsplash-scaled.jpg\";s:5:\"sizes\";a:6:{s:6:\"medium\";a:4:{s:4:\"file\";s:43:\"luca-bravo-O453M2Liufs-unsplash-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:44:\"luca-bravo-O453M2Liufs-unsplash-1024x683.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:683;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:43:\"luca-bravo-O453M2Liufs-unsplash-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:43:\"luca-bravo-O453M2Liufs-unsplash-768x512.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:45:\"luca-bravo-O453M2Liufs-unsplash-1536x1024.jpg\";s:5:\"width\";i:1536;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"2048x2048\";a:4:{s:4:\"file\";s:45:\"luca-bravo-O453M2Liufs-unsplash-2048x1365.jpg\";s:5:\"width\";i:2048;s:6:\"height\";i:1365;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}s:14:\"original_image\";s:35:\"luca-bravo-O453M2Liufs-unsplash.jpg\";}'),
	(43,17,'_wp_attached_file','2020/07/luca-bravo-oV4bR3YoR_s-unsplash-scaled.jpg'),
	(44,17,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:2560;s:6:\"height\";i:1707;s:4:\"file\";s:50:\"2020/07/luca-bravo-oV4bR3YoR_s-unsplash-scaled.jpg\";s:5:\"sizes\";a:6:{s:6:\"medium\";a:4:{s:4:\"file\";s:43:\"luca-bravo-oV4bR3YoR_s-unsplash-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:44:\"luca-bravo-oV4bR3YoR_s-unsplash-1024x683.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:683;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:43:\"luca-bravo-oV4bR3YoR_s-unsplash-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:43:\"luca-bravo-oV4bR3YoR_s-unsplash-768x512.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:45:\"luca-bravo-oV4bR3YoR_s-unsplash-1536x1024.jpg\";s:5:\"width\";i:1536;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"2048x2048\";a:4:{s:4:\"file\";s:45:\"luca-bravo-oV4bR3YoR_s-unsplash-2048x1365.jpg\";s:5:\"width\";i:2048;s:6:\"height\";i:1365;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}s:14:\"original_image\";s:35:\"luca-bravo-oV4bR3YoR_s-unsplash.jpg\";}'),
	(45,18,'_wp_attached_file','2020/07/luca-bravo-VowIFDxogG4-unsplash-scaled.jpg'),
	(46,18,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:2560;s:6:\"height\";i:1707;s:4:\"file\";s:50:\"2020/07/luca-bravo-VowIFDxogG4-unsplash-scaled.jpg\";s:5:\"sizes\";a:6:{s:6:\"medium\";a:4:{s:4:\"file\";s:43:\"luca-bravo-VowIFDxogG4-unsplash-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:44:\"luca-bravo-VowIFDxogG4-unsplash-1024x683.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:683;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:43:\"luca-bravo-VowIFDxogG4-unsplash-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:43:\"luca-bravo-VowIFDxogG4-unsplash-768x512.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:45:\"luca-bravo-VowIFDxogG4-unsplash-1536x1024.jpg\";s:5:\"width\";i:1536;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"2048x2048\";a:4:{s:4:\"file\";s:45:\"luca-bravo-VowIFDxogG4-unsplash-2048x1365.jpg\";s:5:\"width\";i:2048;s:6:\"height\";i:1365;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}s:14:\"original_image\";s:35:\"luca-bravo-VowIFDxogG4-unsplash.jpg\";}'),
	(47,19,'_wp_attached_file','2020/07/luca-bravo-Z87YuMKEiWk-unsplash-scaled.jpg'),
	(48,19,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:2560;s:6:\"height\";i:1707;s:4:\"file\";s:50:\"2020/07/luca-bravo-Z87YuMKEiWk-unsplash-scaled.jpg\";s:5:\"sizes\";a:6:{s:6:\"medium\";a:4:{s:4:\"file\";s:43:\"luca-bravo-Z87YuMKEiWk-unsplash-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:44:\"luca-bravo-Z87YuMKEiWk-unsplash-1024x683.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:683;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:43:\"luca-bravo-Z87YuMKEiWk-unsplash-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:43:\"luca-bravo-Z87YuMKEiWk-unsplash-768x512.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:45:\"luca-bravo-Z87YuMKEiWk-unsplash-1536x1024.jpg\";s:5:\"width\";i:1536;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"2048x2048\";a:4:{s:4:\"file\";s:45:\"luca-bravo-Z87YuMKEiWk-unsplash-2048x1365.jpg\";s:5:\"width\";i:2048;s:6:\"height\";i:1365;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}s:14:\"original_image\";s:35:\"luca-bravo-Z87YuMKEiWk-unsplash.jpg\";}'),
	(49,20,'_wp_attached_file','2020/07/luca-bravo-zAjdgNXsMeg-unsplash-scaled.jpg'),
	(50,20,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:2560;s:6:\"height\";i:1707;s:4:\"file\";s:50:\"2020/07/luca-bravo-zAjdgNXsMeg-unsplash-scaled.jpg\";s:5:\"sizes\";a:6:{s:6:\"medium\";a:4:{s:4:\"file\";s:43:\"luca-bravo-zAjdgNXsMeg-unsplash-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:44:\"luca-bravo-zAjdgNXsMeg-unsplash-1024x683.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:683;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:43:\"luca-bravo-zAjdgNXsMeg-unsplash-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:43:\"luca-bravo-zAjdgNXsMeg-unsplash-768x512.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:45:\"luca-bravo-zAjdgNXsMeg-unsplash-1536x1024.jpg\";s:5:\"width\";i:1536;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"2048x2048\";a:4:{s:4:\"file\";s:45:\"luca-bravo-zAjdgNXsMeg-unsplash-2048x1365.jpg\";s:5:\"width\";i:2048;s:6:\"height\";i:1365;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}s:14:\"original_image\";s:35:\"luca-bravo-zAjdgNXsMeg-unsplash.jpg\";}'),
	(51,21,'meta_description','Hoi daar! Ik ben een fietskoerier in het dagelijks leven en een beginnende acteur in de avonduren. Ik leef in Los Angeles, heb een leuke hond genaamd Jack en ik'),
	(52,21,'_meta_description','field_meta_description'),
	(53,21,'seo_title','Overschreven title'),
	(54,21,'_seo_title','field_seo_title'),
	(55,21,'seo_description','Duis mollis, est non commodo luctus, nisi erat porttitor ligula, eget lacinia odio sem nec elit. Vestibulum id ligula porta felis euismod semper.'),
	(56,21,'_seo_description','field_seo_description'),
	(57,22,'meta_description','Hoi daar! Ik ben een fietskoerier in het dagelijks leven en een beginnende acteur in de avonduren. Ik leef in Los Angeles, heb een leuke hond genaamd Jack en ik'),
	(58,22,'_meta_description','field_meta_description'),
	(59,22,'seo_title','Overschreven title'),
	(60,22,'_seo_title','field_seo_title'),
	(61,22,'seo_description','Duis mollis, est non commodo luctus, nisi erat porttitor ligula, eget lacinia odio sem nec elit. Vestibulum id ligula porta felis euismod semper.'),
	(62,22,'_seo_description','field_seo_description'),
	(63,23,'meta_description','Hoi daar! Ik ben een fietskoerier in het dagelijks leven en een beginnende acteur in de avonduren. Ik leef in Los Angeles, heb een leuke hond genaamd Jack en ik'),
	(64,23,'_meta_description','field_meta_description'),
	(65,23,'seo_title','Overschreven title'),
	(66,23,'_seo_title','field_seo_title'),
	(67,23,'seo_description','Duis mollis, est non commodo luctus, nisi erat porttitor ligula, eget lacinia odio sem nec elit. Vestibulum id ligula porta felis euismod semper.'),
	(68,23,'_seo_description','field_seo_description'),
	(69,2,'header_image','18'),
	(70,2,'_header_image','field_header_image'),
	(71,2,'title',''),
	(72,2,'_title','field_title'),
	(73,2,'og_image',''),
	(74,2,'_og_image','field_og_image'),
	(75,24,'meta_description','Hoi daar! Ik ben een fietskoerier in het dagelijks leven en een beginnende acteur in de avonduren. Ik leef in Los Angeles, heb een leuke hond genaamd Jack en ik'),
	(76,24,'_meta_description','field_meta_description'),
	(77,24,'seo_title','Overschreven title'),
	(78,24,'_seo_title','field_seo_title'),
	(79,24,'seo_description','Duis mollis, est non commodo luctus, nisi erat porttitor ligula, eget lacinia odio sem nec elit. Vestibulum id ligula porta felis euismod semper.'),
	(80,24,'_seo_description','field_seo_description'),
	(81,24,'header_image','17'),
	(82,24,'_header_image','field_header_image'),
	(83,24,'title',''),
	(84,24,'_title','field_title'),
	(85,24,'og_image',''),
	(86,24,'_og_image','field_og_image'),
	(87,25,'_wp_attached_file','2020/07/00.jpg'),
	(88,25,'_wp_attachment_metadata','a:5:{s:5:\"width\";i:600;s:6:\"height\";i:450;s:4:\"file\";s:14:\"2020/07/00.jpg\";s:5:\"sizes\";a:2:{s:6:\"medium\";a:4:{s:4:\"file\";s:14:\"00-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:14:\"00-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
	(89,26,'meta_description','Hoi daar! Ik ben een fietskoerier in het dagelijks leven en een beginnende acteur in de avonduren. Ik leef in Los Angeles, heb een leuke hond genaamd Jack en ik'),
	(90,26,'_meta_description','field_meta_description'),
	(91,26,'seo_title','Overschreven title'),
	(92,26,'_seo_title','field_seo_title'),
	(93,26,'seo_description','Duis mollis, est non commodo luctus, nisi erat porttitor ligula, eget lacinia odio sem nec elit. Vestibulum id ligula porta felis euismod semper.'),
	(94,26,'_seo_description','field_seo_description'),
	(95,26,'header_image','19'),
	(96,26,'_header_image','field_header_image'),
	(97,26,'title',''),
	(98,26,'_title','field_title'),
	(99,26,'og_image',''),
	(100,26,'_og_image','field_og_image'),
	(101,27,'meta_description','Hoi daar! Ik ben een fietskoerier in het dagelijks leven en een beginnende acteur in de avonduren. Ik leef in Los Angeles, heb een leuke hond genaamd Jack en ik'),
	(102,27,'_meta_description','field_meta_description'),
	(103,27,'seo_title','Overschreven title'),
	(104,27,'_seo_title','field_seo_title'),
	(105,27,'seo_description','Duis mollis, est non commodo luctus, nisi erat porttitor ligula, eget lacinia odio sem nec elit. Vestibulum id ligula porta felis euismod semper.'),
	(106,27,'_seo_description','field_seo_description'),
	(107,27,'header_image','18'),
	(108,27,'_header_image','field_header_image'),
	(109,27,'title',''),
	(110,27,'_title','field_title'),
	(111,27,'og_image',''),
	(112,27,'_og_image','field_og_image'),
	(113,30,'meta_description','Hoi daar! Ik ben een fietskoerier in het dagelijks leven en een beginnende acteur in de avonduren. Ik leef in Los Angeles, heb een leuke hond genaamd Jack en ik'),
	(114,30,'_meta_description','field_meta_description'),
	(115,30,'seo_title','Overschreven title'),
	(116,30,'_seo_title','field_seo_title'),
	(117,30,'seo_description','Duis mollis, est non commodo luctus, nisi erat porttitor ligula, eget lacinia odio sem nec elit. Vestibulum id ligula porta felis euismod semper.'),
	(118,30,'_seo_description','field_seo_description'),
	(119,30,'header_image','18'),
	(120,30,'_header_image','field_header_image'),
	(121,30,'title',''),
	(122,30,'_title','field_title'),
	(123,30,'og_image',''),
	(124,30,'_og_image','field_og_image'),
	(125,32,'_edit_lock','1595334155:1'),
	(126,32,'_edit_last','1'),
	(127,32,'header_image',''),
	(128,32,'_header_image','field_header_image'),
	(129,32,'title',''),
	(130,32,'_title','field_title'),
	(131,32,'meta_description',''),
	(132,32,'_meta_description','field_meta_description'),
	(133,32,'og_image',''),
	(134,32,'_og_image','field_og_image'),
	(135,33,'header_image',''),
	(136,33,'_header_image','field_header_image'),
	(137,33,'title',''),
	(138,33,'_title','field_title'),
	(139,33,'meta_description',''),
	(140,33,'_meta_description','field_meta_description'),
	(141,33,'og_image',''),
	(142,33,'_og_image','field_og_image'),
	(143,34,'_menu_item_type','post_type'),
	(144,34,'_menu_item_menu_item_parent','35'),
	(145,34,'_menu_item_object_id','32'),
	(146,34,'_menu_item_object','page'),
	(147,34,'_menu_item_target',''),
	(148,34,'_menu_item_classes','a:1:{i:0;s:0:\"\";}'),
	(149,34,'_menu_item_xfn',''),
	(150,34,'_menu_item_url',''),
	(152,35,'_menu_item_type','post_type'),
	(153,35,'_menu_item_menu_item_parent','0'),
	(154,35,'_menu_item_object_id','2'),
	(155,35,'_menu_item_object','page'),
	(156,35,'_menu_item_target',''),
	(157,35,'_menu_item_classes','a:1:{i:0;s:0:\"\";}'),
	(158,35,'_menu_item_xfn',''),
	(159,35,'_menu_item_url',''),
	(161,36,'_menu_item_type','custom'),
	(162,36,'_menu_item_menu_item_parent','0'),
	(163,36,'_menu_item_object_id','36'),
	(164,36,'_menu_item_object','custom'),
	(165,36,'_menu_item_target',''),
	(166,36,'_menu_item_classes','a:1:{i:0;s:0:\"\";}'),
	(167,36,'_menu_item_xfn',''),
	(168,36,'_menu_item_url','https://headless-wordpress.lndo.site/'),
	(170,37,'_menu_item_type','post_type'),
	(171,37,'_menu_item_menu_item_parent','0'),
	(172,37,'_menu_item_object_id','8'),
	(173,37,'_menu_item_object','post'),
	(174,37,'_menu_item_target',''),
	(175,37,'_menu_item_classes','a:1:{i:0;s:0:\"\";}'),
	(176,37,'_menu_item_xfn',''),
	(177,37,'_menu_item_url',''),
	(179,38,'_menu_item_type','post_type'),
	(180,38,'_menu_item_menu_item_parent','35'),
	(181,38,'_menu_item_object_id','3'),
	(182,38,'_menu_item_object','page'),
	(183,38,'_menu_item_target',''),
	(184,38,'_menu_item_classes','a:1:{i:0;s:0:\"\";}'),
	(185,38,'_menu_item_xfn',''),
	(186,38,'_menu_item_url',''),
	(188,39,'_menu_item_type','post_type'),
	(189,39,'_menu_item_menu_item_parent','0'),
	(190,39,'_menu_item_object_id','32'),
	(191,39,'_menu_item_object','page'),
	(192,39,'_menu_item_target',''),
	(193,39,'_menu_item_classes','a:1:{i:0;s:0:\"\";}'),
	(194,39,'_menu_item_xfn',''),
	(195,39,'_menu_item_url',''),
	(197,40,'_menu_item_type','post_type'),
	(198,40,'_menu_item_menu_item_parent','35'),
	(199,40,'_menu_item_object_id','2'),
	(200,40,'_menu_item_object','page'),
	(201,40,'_menu_item_target',''),
	(202,40,'_menu_item_classes','a:1:{i:0;s:0:\"\";}'),
	(203,40,'_menu_item_xfn',''),
	(204,40,'_menu_item_url',''),
	(206,41,'_menu_item_type','post_type'),
	(207,41,'_menu_item_menu_item_parent','0'),
	(208,41,'_menu_item_object_id','3'),
	(209,41,'_menu_item_object','page'),
	(210,41,'_menu_item_target',''),
	(211,41,'_menu_item_classes','a:1:{i:0;s:0:\"\";}'),
	(212,41,'_menu_item_xfn',''),
	(213,41,'_menu_item_url',''),
	(215,42,'_menu_item_type','custom'),
	(216,42,'_menu_item_menu_item_parent','0'),
	(217,42,'_menu_item_object_id','42'),
	(218,42,'_menu_item_object','custom'),
	(219,42,'_menu_item_target',''),
	(220,42,'_menu_item_classes','a:1:{i:0;s:0:\"\";}'),
	(221,42,'_menu_item_xfn',''),
	(222,42,'_menu_item_url','https://headless-wordpress.lndo.site/'),
	(224,43,'_menu_item_type','custom'),
	(225,43,'_menu_item_menu_item_parent','0'),
	(226,43,'_menu_item_object_id','43'),
	(227,43,'_menu_item_object','custom'),
	(228,43,'_menu_item_target',''),
	(229,43,'_menu_item_classes','a:1:{i:0;s:0:\"\";}'),
	(230,43,'_menu_item_xfn',''),
	(231,43,'_menu_item_url','https://www.trendwerk.nl');

/*!40000 ALTER TABLE `wp_postmeta` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table wp_posts
# ------------------------------------------------------------

DROP TABLE IF EXISTS `wp_posts`;

CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

LOCK TABLES `wp_posts` WRITE;
/*!40000 ALTER TABLE `wp_posts` DISABLE KEYS */;

INSERT INTO `wp_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`)
VALUES
	(1,1,'2020-07-15 12:04:58','2020-07-15 12:04:58','<!-- wp:paragraph -->\n<p>Welkom bij WordPress. Dit is je eerste bericht. Bewerk of verwijder het, start dan met schrijven!</p>\n<!-- /wp:paragraph -->','Hallo wereld.','','publish','open','open','','hallo-wereld','','','2020-07-15 12:04:58','2020-07-15 12:04:58','',0,'https://headless-wordpress.lndo.site/?p=1',0,'post','',1),
	(2,1,'2020-07-15 12:04:58','2020-07-15 12:04:58','<!-- wp:paragraph -->\n<p>Dit is een voorbeeldpagina. Het is anders dan een blog bericht omdat het op één plek blijft en tevoorschijn komt in je site navigatie (in de meeste thema\'s). De meeste mensen starten met een Over pagina dat hen voorstelt aan potentiële site bezoekers. Het zou iets als dit kunnen zeggen:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:buttons -->\n<div class=\"wp-block-buttons\"><!-- wp:button -->\n<div class=\"wp-block-button\"><a class=\"wp-block-button__link\" href=\"https://headless-wordpress.lndo.site/privacybeleid/\">Ik vind er iets van</a></div>\n<!-- /wp:button --></div>\n<!-- /wp:buttons -->\n\n<!-- wp:image {\"id\":18,\"sizeSlug\":\"large\"} -->\n<figure class=\"wp-block-image size-large\"><img src=\"https://headless-wordpress.lndo.site/app/uploads/2020/07/luca-bravo-VowIFDxogG4-unsplash-1024x683.jpg\" alt=\"\" class=\"wp-image-18\"/></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p>Leuk hoor! Geweldig!</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>Hoi daar! Ik ben een fietskoerier in het dagelijks leven en een beginnende acteur in de avonduren. Ik leef in Los Angeles, heb een leuke hond genaamd Jack en ik hou van piña coladas. (En overvallen worden door de regen.)</p><cite>Jan de man</cite></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:heading -->\n<h2>Of zoiets als dit</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>De XYZ Doohickey Company is opgericht in 1971 en heeft sindsdien kwalitatieve   doohickeys aan het publiek geleverd. Gevestigd in Gotham City, XYZ heeft meer dan 2000 mensen in dienst en doen allemaal fantastische dingen voor de community in Gotham.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Als nieuwe WordPress gebruiker kan je naar <a href=\"https://headless-wordpress.lndo.site/wp/wp-admin/\">je dashboard</a> gaan om deze pagina te verwijderen en nieuwe pagina\'s toe te voegen voor je inhoud. Veel plezier!</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading {\"level\":3} -->\n<h3>Hier nog een H3 kopje</h3>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Sed posuere consectetur est at lobortis. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Donec id elit non mi porta gravida at eget metus. Donec ullamcorper nulla non metus auctor fringilla.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Nulla vitae elit libero, a pharetra augue. Integer posuere erat a ante venenatis dapibus posuere velit aliquet. Maecenas faucibus mollis interdum. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent commodo cursus magna, vel scelerisque nisl consectetur et. Donec ullamcorper nulla non metus auctor fringilla.</p>\n<!-- /wp:paragraph -->','Voorbeeld pagina','','publish','closed','open','','voorbeeld-pagina','','','2020-07-20 19:34:55','2020-07-20 19:34:55','',0,'https://headless-wordpress.lndo.site/?page_id=2',0,'page','',0),
	(3,1,'2020-07-15 12:04:58','2020-07-15 12:04:58','<!-- wp:heading -->\n<h2>Wie zijn we</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Ons website-adres is: https://headless-wordpress.lndo.site.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2>Welke persoonlijke gegevens we verzamelen en waarom we die verzamelen</h2>\n<!-- /wp:heading -->\n\n<!-- wp:heading {\"level\":3} -->\n<h3>Reacties</h3>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Als bezoekers reacties achterlaten op de site, verzamelen we de gegevens getoond in het reactieformulier, het IP-adres van de bezoeker en de browser user agent om te helpen spam te detecteren.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Een geanonimiseerde string, gemaakt op basis van je e-mailadres (dit wordt ook een hash genoemd) kan worden gestuurd naar de Gravatar service indien je dit gebruikt. De privacybeleidspagina kun je hier vinden: https://automattic.com/privacy/. Nadat je reactie is goedgekeurd, is je profielfoto publiekelijk zichtbaar in de context van je reactie.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading {\"level\":3} -->\n<h3>Media</h3>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Als je een geregistreerde gebruiker bent en afbeeldingen naar de site upload, moet je voorkomen dat je afbeeldingen uploadt met daarin EXIF GPS locatie gegevens. Bezoekers van de website kunnen de afbeeldingen van de website downloaden en de locatiegegevens inzien.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading {\"level\":3} -->\n<h3>Contactformulieren</h3>\n<!-- /wp:heading -->\n\n<!-- wp:heading {\"level\":3} -->\n<h3>Cookies</h3>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Wanneer je een reactie achterlaat op onze site, kun je aangeven of je naam, je e-mailadres en website in een cookie opgeslagen mogen worden. Dit doen we voor jouw gemak zodat je deze gegevens niet opnieuw hoeft in te vullen voor een nieuwe reactie. Deze cookies zijn een jaar lang geldig. </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Indien je onze inlogpagina bezoekt, slaan we een tijdelijke cookie op om te controleren of je browser cookies accepteert. Deze cookie bevat geen persoonlijke gegevens en wordt verwijderd zodra je je browser sluit.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Zodra je inlogt, zullen we enkele cookies bewaren in verband met jouw login informatie en schermweergave opties. Login cookies zijn 2 dagen geldig en cookies voor schermweergave opties 1 jaar. Als je \"Herinner mij\" selecteert, wordt je login 2 weken bewaard. Zodra je uitlogt van jouw account, worden login cookies verwijderd.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Wanneer je een bericht wijzigt of publiceert wordt een aanvullende cookie door je browser opgeslagen. Deze cookie bevat geen persoonlijke data en heeft enkel het post ID van het artikel wat je hebt bewerkt in zich. Deze cookie is na een dag verlopen.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading {\"level\":3} -->\n<h3>Ingesloten inhoud van andere websites</h3>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Berichten op deze site kunnen ingesloten (embedded) inhoud bevatten (bijvoorbeeld video\'s, afbeeldingen, berichten, etc.). Ingesloten inhoud van andere websites gedraagt zich exact hetzelfde alsof de bezoeker deze andere website heeft bezocht.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Deze websites kunnen data over jou verzamelen, cookies gebruiken, tracking van derde partijen insluiten en je interactie met deze ingesloten inhoud monitoren, inclusief de interactie met ingesloten inhoud als je een account hebt en ingelogd bent op die website.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading {\"level\":3} -->\n<h3>Analytics</h3>\n<!-- /wp:heading -->\n\n<!-- wp:heading -->\n<h2>Met wie we jouw gegevens delen</h2>\n<!-- /wp:heading -->\n\n<!-- wp:heading -->\n<h2>Hoe lang we jouw gegevens bewaren</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Wanneer je een reactie achterlaat dan wordt die reactie en de metadata van die reactie voor altijd bewaard. Op deze manier kunnen we vervolgreacties automatisch herkennen en goedkeuren in plaats van dat we ze moeten modereren.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Voor gebruikers die geregistreerd op onze website (indien van toepassing), bewaren we ook persoonlijke informatie in hun gebruikersprofiel. Alle gebruikers kunnen hun persoonlijke informatie bekijken, wijzigen of verwijderen op ieder moment (de gebruikersnaam kan niet gewijzigd worden). Website beheerders kunnen deze informatie ook bekijken en wijzigen.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2>Welke rechten je hebt over je gegevens</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Als je een account hebt op deze site of je hebt reacties achter gelaten, kan je verzoeken om een exportbestand van je persoonlijke gegevens die we van je hebben, inclusief alle gegevens die je ons opgegeven hebt. Je kan ook verzoeken dat we alle persoonlijke gegevens die we van je hebben verwijderen. Dit bevat geen gegevens die we verplicht moeten bewaren in verband met administratieve, wettelijke of beveiligings doeleinden.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2>Waar we jouw gegevens naartoe sturen</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Reacties van bezoekers kunnen door een geautomatiseerde spamdetectie service geleid worden.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2>Jouw contactinformatie</h2>\n<!-- /wp:heading -->\n\n<!-- wp:heading -->\n<h2>Aanvullende informatie</h2>\n<!-- /wp:heading -->\n\n<!-- wp:heading {\"level\":3} -->\n<h3>Hoe we jouw gegevens beschermen</h3>\n<!-- /wp:heading -->\n\n<!-- wp:heading {\"level\":3} -->\n<h3>Welke datalek procedures we geïmplementeerd hebben</h3>\n<!-- /wp:heading -->\n\n<!-- wp:heading {\"level\":3} -->\n<h3>Van welke derde partijen we gegevens ontvangen</h3>\n<!-- /wp:heading -->\n\n<!-- wp:heading {\"level\":3} -->\n<h3>Wat voor geautomatiseerde besluiten we nemen en profilering we doen met gebruikersgegevens</h3>\n<!-- /wp:heading -->\n\n<!-- wp:heading {\"level\":3} -->\n<h3>Openbaarmakingsverplichtingen van de industrie</h3>\n<!-- /wp:heading -->','Privacybeleid','','publish','closed','open','','privacybeleid','','','2020-07-17 12:25:33','2020-07-17 12:25:33','',0,'https://headless-wordpress.lndo.site/?page_id=3',0,'page','',0),
	(5,1,'2020-07-15 12:53:15','2020-07-15 12:53:15','<!-- wp:paragraph -->\n<p>Dit is een voorbeeldpagina. Het is anders dan een blog bericht omdat het op één plek blijft en tevoorschijn komt in je site navigatie (in de meeste thema\'s). De meeste mensen starten met een Over pagina dat hen voorstelt aan potentiële site bezoekers. Het zou iets als dit kunnen zeggen:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>leuk hoor!</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>Hoi daar! Ik ben een fietskoerier in het dagelijks leven en een beginnende acteur in de avonduren. Ik leef in Los Angeles, heb een leuke hond genaamd Jack en ik hou van piña coladas. (En overvallen worden door de regen.)</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>...of zoiets als dit:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>De XYZ Doohickey Company is opgericht in 1971 en heeft sindsdien kwalitatieve   doohickeys aan het publiek geleverd. Gevestigd in Gotham City, XYZ heeft meer dan 2000 mensen in dienst en doen allemaal fantastische dingen voor de community in Gotham.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>Als nieuwe WordPress gebruiker kan je naar <a href=\"https://headless-wordpress.lndo.site/wp/wp-admin/\">je dashboard</a> gaan om deze pagina te verwijderen en nieuwe pagina\'s toe te voegen voor je inhoud. Veel plezier!</p>\n<!-- /wp:paragraph -->','Voorbeeld pagina','','inherit','closed','closed','','2-revision-v1','','','2020-07-15 12:53:15','2020-07-15 12:53:15','',2,'https://headless-wordpress.lndo.site/2020/07/15/2-revision-v1/',0,'revision','',0),
	(6,1,'2020-07-15 12:53:29','2020-07-15 12:53:29','<!-- wp:paragraph -->\n<p>Dit is een voorbeeldpagina. Het is anders dan een blog bericht omdat het op één plek blijft en tevoorschijn komt in je site navigatie (in de meeste thema\'s). De meeste mensen starten met een Over pagina dat hen voorstelt aan potentiële site bezoekers. Het zou iets als dit kunnen zeggen:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>leuk hoor! Geweldig!</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>Hoi daar! Ik ben een fietskoerier in het dagelijks leven en een beginnende acteur in de avonduren. Ik leef in Los Angeles, heb een leuke hond genaamd Jack en ik hou van piña coladas. (En overvallen worden door de regen.)</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>...of zoiets als dit:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>De XYZ Doohickey Company is opgericht in 1971 en heeft sindsdien kwalitatieve   doohickeys aan het publiek geleverd. Gevestigd in Gotham City, XYZ heeft meer dan 2000 mensen in dienst en doen allemaal fantastische dingen voor de community in Gotham.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>Als nieuwe WordPress gebruiker kan je naar <a href=\"https://headless-wordpress.lndo.site/wp/wp-admin/\">je dashboard</a> gaan om deze pagina te verwijderen en nieuwe pagina\'s toe te voegen voor je inhoud. Veel plezier!</p>\n<!-- /wp:paragraph -->','Voorbeeld pagina','','inherit','closed','closed','','2-revision-v1','','','2020-07-15 12:53:29','2020-07-15 12:53:29','',2,'https://headless-wordpress.lndo.site/2020/07/15/2-revision-v1/',0,'revision','',0),
	(7,1,'2020-07-15 19:20:57','0000-00-00 00:00:00','','Automatische concepten','','auto-draft','closed','closed','','','','','2020-07-15 19:20:57','0000-00-00 00:00:00','',0,'https://headless-wordpress.lndo.site/?page_id=7',0,'page','',0),
	(8,1,'2020-07-15 19:21:19','2020-07-15 19:21:19','<!-- wp:paragraph -->\n<p>Blabla hier wat tekst.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Nog wat tekst.</p>\n<!-- /wp:paragraph -->','Nog een post','','publish','open','open','','nog-een-post','','','2020-07-15 19:21:19','2020-07-15 19:21:19','',0,'https://headless-wordpress.lndo.site/?p=8',0,'post','',0),
	(9,1,'2020-07-15 19:21:19','2020-07-15 19:21:19','<!-- wp:paragraph -->\n<p>Blabla hier wat tekst.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Nog wat tekst.</p>\n<!-- /wp:paragraph -->','Nog een post','','inherit','closed','closed','','8-revision-v1','','','2020-07-15 19:21:19','2020-07-15 19:21:19','',8,'https://headless-wordpress.lndo.site/8-revision-v1/',0,'revision','',0),
	(10,1,'2020-07-17 09:46:17','2020-07-17 09:46:17','<!-- wp:paragraph -->\n<p>Dit is een voorbeeldpagina. Het is anders dan een blog bericht omdat het op één plek blijft en tevoorschijn komt in je site navigatie (in de meeste thema\'s). De meeste mensen starten met een Over pagina dat hen voorstelt aan potentiële site bezoekers. Het zou iets als dit kunnen zeggen:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>leuk hoor! Geweldig!</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>Hoi daar! Ik ben een fietskoerier in het dagelijks leven en een beginnende acteur in de avonduren. Ik leef in Los Angeles, heb een leuke hond genaamd Jack en ik hou van piña coladas. (En overvallen worden door de regen.)</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>...of zoiets als dit:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>De XYZ Doohickey Company is opgericht in 1971 en heeft sindsdien kwalitatieve   doohickeys aan het publiek geleverd. Gevestigd in Gotham City, XYZ heeft meer dan 2000 mensen in dienst en doen allemaal fantastische dingen voor de community in Gotham.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>Als nieuwe WordPress gebruiker kan je naar <a href=\"https://headless-wordpress.lndo.site/wp/wp-admin/\">je dashboard</a> gaan om deze pagina te verwijderen en nieuwe pagina\'s toe te voegen voor je inhoud. Veel plezier!</p>\n<!-- /wp:paragraph -->','Voorbeeld pagina','','inherit','closed','closed','','2-revision-v1','','','2020-07-17 09:46:17','2020-07-17 09:46:17','',2,'https://headless-wordpress.lndo.site/2-revision-v1/',0,'revision','',0),
	(11,1,'2020-07-17 11:31:31','2020-07-17 11:31:31','<!-- wp:paragraph -->\n<p>Dit is een voorbeeldpagina. Het is anders dan een blog bericht omdat het op één plek blijft en tevoorschijn komt in je site navigatie (in de meeste thema\'s). De meeste mensen starten met een Over pagina dat hen voorstelt aan potentiële site bezoekers. Het zou iets als dit kunnen zeggen:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>leuk hoor! Geweldig!</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>Hoi daar! Ik ben een fietskoerier in het dagelijks leven en een beginnende acteur in de avonduren. Ik leef in Los Angeles, heb een leuke hond genaamd Jack en ik hou van piña coladas. (En overvallen worden door de regen.)</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>...of zoiets als dit:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>De XYZ Doohickey Company is opgericht in 1971 en heeft sindsdien kwalitatieve   doohickeys aan het publiek geleverd. Gevestigd in Gotham City, XYZ heeft meer dan 2000 mensen in dienst en doen allemaal fantastische dingen voor de community in Gotham.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>Als nieuwe WordPress gebruiker kan je naar <a href=\"https://headless-wordpress.lndo.site/wp/wp-admin/\">je dashboard</a> gaan om deze pagina te verwijderen en nieuwe pagina\'s toe te voegen voor je inhoud. Veel plezier!</p>\n<!-- /wp:paragraph -->','Voorbeeld pagina','','inherit','closed','closed','','2-revision-v1','','','2020-07-17 11:31:31','2020-07-17 11:31:31','',2,'https://headless-wordpress.lndo.site/2-revision-v1/',0,'revision','',0),
	(12,1,'2020-07-17 12:25:32','2020-07-17 12:25:32','<!-- wp:heading -->\n<h2>Wie zijn we</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Ons website-adres is: https://headless-wordpress.lndo.site.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2>Welke persoonlijke gegevens we verzamelen en waarom we die verzamelen</h2>\n<!-- /wp:heading -->\n\n<!-- wp:heading {\"level\":3} -->\n<h3>Reacties</h3>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Als bezoekers reacties achterlaten op de site, verzamelen we de gegevens getoond in het reactieformulier, het IP-adres van de bezoeker en de browser user agent om te helpen spam te detecteren.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Een geanonimiseerde string, gemaakt op basis van je e-mailadres (dit wordt ook een hash genoemd) kan worden gestuurd naar de Gravatar service indien je dit gebruikt. De privacybeleidspagina kun je hier vinden: https://automattic.com/privacy/. Nadat je reactie is goedgekeurd, is je profielfoto publiekelijk zichtbaar in de context van je reactie.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading {\"level\":3} -->\n<h3>Media</h3>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Als je een geregistreerde gebruiker bent en afbeeldingen naar de site upload, moet je voorkomen dat je afbeeldingen uploadt met daarin EXIF GPS locatie gegevens. Bezoekers van de website kunnen de afbeeldingen van de website downloaden en de locatiegegevens inzien.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading {\"level\":3} -->\n<h3>Contactformulieren</h3>\n<!-- /wp:heading -->\n\n<!-- wp:heading {\"level\":3} -->\n<h3>Cookies</h3>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Wanneer je een reactie achterlaat op onze site, kun je aangeven of je naam, je e-mailadres en website in een cookie opgeslagen mogen worden. Dit doen we voor jouw gemak zodat je deze gegevens niet opnieuw hoeft in te vullen voor een nieuwe reactie. Deze cookies zijn een jaar lang geldig. </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Indien je onze inlogpagina bezoekt, slaan we een tijdelijke cookie op om te controleren of je browser cookies accepteert. Deze cookie bevat geen persoonlijke gegevens en wordt verwijderd zodra je je browser sluit.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Zodra je inlogt, zullen we enkele cookies bewaren in verband met jouw login informatie en schermweergave opties. Login cookies zijn 2 dagen geldig en cookies voor schermweergave opties 1 jaar. Als je \"Herinner mij\" selecteert, wordt je login 2 weken bewaard. Zodra je uitlogt van jouw account, worden login cookies verwijderd.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Wanneer je een bericht wijzigt of publiceert wordt een aanvullende cookie door je browser opgeslagen. Deze cookie bevat geen persoonlijke data en heeft enkel het post ID van het artikel wat je hebt bewerkt in zich. Deze cookie is na een dag verlopen.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading {\"level\":3} -->\n<h3>Ingesloten inhoud van andere websites</h3>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Berichten op deze site kunnen ingesloten (embedded) inhoud bevatten (bijvoorbeeld video\'s, afbeeldingen, berichten, etc.). Ingesloten inhoud van andere websites gedraagt zich exact hetzelfde alsof de bezoeker deze andere website heeft bezocht.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Deze websites kunnen data over jou verzamelen, cookies gebruiken, tracking van derde partijen insluiten en je interactie met deze ingesloten inhoud monitoren, inclusief de interactie met ingesloten inhoud als je een account hebt en ingelogd bent op die website.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading {\"level\":3} -->\n<h3>Analytics</h3>\n<!-- /wp:heading -->\n\n<!-- wp:heading -->\n<h2>Met wie we jouw gegevens delen</h2>\n<!-- /wp:heading -->\n\n<!-- wp:heading -->\n<h2>Hoe lang we jouw gegevens bewaren</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Wanneer je een reactie achterlaat dan wordt die reactie en de metadata van die reactie voor altijd bewaard. Op deze manier kunnen we vervolgreacties automatisch herkennen en goedkeuren in plaats van dat we ze moeten modereren.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Voor gebruikers die geregistreerd op onze website (indien van toepassing), bewaren we ook persoonlijke informatie in hun gebruikersprofiel. Alle gebruikers kunnen hun persoonlijke informatie bekijken, wijzigen of verwijderen op ieder moment (de gebruikersnaam kan niet gewijzigd worden). Website beheerders kunnen deze informatie ook bekijken en wijzigen.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2>Welke rechten je hebt over je gegevens</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Als je een account hebt op deze site of je hebt reacties achter gelaten, kan je verzoeken om een exportbestand van je persoonlijke gegevens die we van je hebben, inclusief alle gegevens die je ons opgegeven hebt. Je kan ook verzoeken dat we alle persoonlijke gegevens die we van je hebben verwijderen. Dit bevat geen gegevens die we verplicht moeten bewaren in verband met administratieve, wettelijke of beveiligings doeleinden.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2>Waar we jouw gegevens naartoe sturen</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Reacties van bezoekers kunnen door een geautomatiseerde spamdetectie service geleid worden.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2>Jouw contactinformatie</h2>\n<!-- /wp:heading -->\n\n<!-- wp:heading -->\n<h2>Aanvullende informatie</h2>\n<!-- /wp:heading -->\n\n<!-- wp:heading {\"level\":3} -->\n<h3>Hoe we jouw gegevens beschermen</h3>\n<!-- /wp:heading -->\n\n<!-- wp:heading {\"level\":3} -->\n<h3>Welke datalek procedures we geïmplementeerd hebben</h3>\n<!-- /wp:heading -->\n\n<!-- wp:heading {\"level\":3} -->\n<h3>Van welke derde partijen we gegevens ontvangen</h3>\n<!-- /wp:heading -->\n\n<!-- wp:heading {\"level\":3} -->\n<h3>Wat voor geautomatiseerde besluiten we nemen en profilering we doen met gebruikersgegevens</h3>\n<!-- /wp:heading -->\n\n<!-- wp:heading {\"level\":3} -->\n<h3>Openbaarmakingsverplichtingen van de industrie</h3>\n<!-- /wp:heading -->','Privacybeleid','','inherit','closed','closed','','3-revision-v1','','','2020-07-17 12:25:32','2020-07-17 12:25:32','',3,'https://headless-wordpress.lndo.site/3-revision-v1/',0,'revision','',0),
	(14,1,'2020-07-17 18:26:20','2020-07-17 18:26:20','','luca-bravo-ESkw2ayO2As-unsplash','','inherit','open','closed','','luca-bravo-eskw2ayo2as-unsplash','','','2020-07-17 18:26:20','2020-07-17 18:26:20','',0,'https://headless-wordpress.lndo.site/app/uploads/2020/07/luca-bravo-ESkw2ayO2As-unsplash.jpg',0,'attachment','image/jpeg',0),
	(15,1,'2020-07-17 18:26:28','2020-07-17 18:26:28','','luca-bravo-hFzIoD0F_i8-unsplash','','inherit','open','closed','','luca-bravo-hfziod0f_i8-unsplash','','','2020-07-17 18:26:28','2020-07-17 18:26:28','',0,'https://headless-wordpress.lndo.site/app/uploads/2020/07/luca-bravo-hFzIoD0F_i8-unsplash.jpg',0,'attachment','image/jpeg',0),
	(16,1,'2020-07-17 18:26:33','2020-07-17 18:26:33','','luca-bravo-O453M2Liufs-unsplash','','inherit','open','closed','','luca-bravo-o453m2liufs-unsplash','','','2020-07-17 18:26:33','2020-07-17 18:26:33','',0,'https://headless-wordpress.lndo.site/app/uploads/2020/07/luca-bravo-O453M2Liufs-unsplash.jpg',0,'attachment','image/jpeg',0),
	(17,1,'2020-07-17 18:26:40','2020-07-17 18:26:40','','luca-bravo-oV4bR3YoR_s-unsplash','','inherit','open','closed','','luca-bravo-ov4br3yor_s-unsplash','','','2020-07-17 20:56:36','2020-07-17 20:56:36','',2,'https://headless-wordpress.lndo.site/app/uploads/2020/07/luca-bravo-oV4bR3YoR_s-unsplash.jpg',0,'attachment','image/jpeg',0),
	(18,1,'2020-07-17 18:26:44','2020-07-17 18:26:44','','luca-bravo-VowIFDxogG4-unsplash','','inherit','open','closed','','luca-bravo-vowifdxogg4-unsplash','','','2020-07-20 14:47:35','2020-07-20 14:47:35','',2,'https://headless-wordpress.lndo.site/app/uploads/2020/07/luca-bravo-VowIFDxogG4-unsplash.jpg',0,'attachment','image/jpeg',0),
	(19,1,'2020-07-17 18:26:48','2020-07-17 18:26:48','','luca-bravo-Z87YuMKEiWk-unsplash','','inherit','open','closed','','luca-bravo-z87yumkeiwk-unsplash','','','2020-07-17 20:59:35','2020-07-17 20:59:35','',2,'https://headless-wordpress.lndo.site/app/uploads/2020/07/luca-bravo-Z87YuMKEiWk-unsplash.jpg',0,'attachment','image/jpeg',0),
	(20,1,'2020-07-17 18:26:55','2020-07-17 18:26:55','','luca-bravo-zAjdgNXsMeg-unsplash','','inherit','open','closed','','luca-bravo-zajdgnxsmeg-unsplash','','','2020-07-17 18:26:55','2020-07-17 18:26:55','',0,'https://headless-wordpress.lndo.site/app/uploads/2020/07/luca-bravo-zAjdgNXsMeg-unsplash.jpg',0,'attachment','image/jpeg',0),
	(21,1,'2020-07-17 18:33:01','2020-07-17 18:33:01','<!-- wp:paragraph -->\n<p>Dit is een voorbeeldpagina. Het is anders dan een blog bericht omdat het op één plek blijft en tevoorschijn komt in je site navigatie (in de meeste thema\'s). De meeste mensen starten met een Over pagina dat hen voorstelt aan potentiële site bezoekers. Het zou iets als dit kunnen zeggen:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image {\"id\":18,\"sizeSlug\":\"large\"} -->\n<figure class=\"wp-block-image size-large\"><img src=\"https://headless-wordpress.lndo.site/app/uploads/2020/07/luca-bravo-VowIFDxogG4-unsplash-1024x683.jpg\" alt=\"\" class=\"wp-image-18\"/></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p>leuk hoor! Geweldig!</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>Hoi daar! Ik ben een fietskoerier in het dagelijks leven en een beginnende acteur in de avonduren. Ik leef in Los Angeles, heb een leuke hond genaamd Jack en ik hou van piña coladas. (En overvallen worden door de regen.)</p><cite>Jan de man</cite></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>...of zoiets als dit:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>De XYZ Doohickey Company is opgericht in 1971 en heeft sindsdien kwalitatieve   doohickeys aan het publiek geleverd. Gevestigd in Gotham City, XYZ heeft meer dan 2000 mensen in dienst en doen allemaal fantastische dingen voor de community in Gotham.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:gallery {\"ids\":[20,19,18,17,16,15,14],\"columns\":4} -->\n<figure class=\"wp-block-gallery columns-4 is-cropped\"><ul class=\"blocks-gallery-grid\"><li class=\"blocks-gallery-item\"><figure><img src=\"https://headless-wordpress.lndo.site/app/uploads/2020/07/luca-bravo-zAjdgNXsMeg-unsplash-1024x683.jpg\" alt=\"\" data-id=\"20\" data-full-url=\"https://headless-wordpress.lndo.site/app/uploads/2020/07/luca-bravo-zAjdgNXsMeg-unsplash-scaled.jpg\" data-link=\"https://headless-wordpress.lndo.site/luca-bravo-zajdgnxsmeg-unsplash/\" class=\"wp-image-20\"/></figure></li><li class=\"blocks-gallery-item\"><figure><img src=\"https://headless-wordpress.lndo.site/app/uploads/2020/07/luca-bravo-Z87YuMKEiWk-unsplash-1024x683.jpg\" alt=\"\" data-id=\"19\" data-full-url=\"https://headless-wordpress.lndo.site/app/uploads/2020/07/luca-bravo-Z87YuMKEiWk-unsplash-scaled.jpg\" data-link=\"https://headless-wordpress.lndo.site/luca-bravo-z87yumkeiwk-unsplash/\" class=\"wp-image-19\"/></figure></li><li class=\"blocks-gallery-item\"><figure><img src=\"https://headless-wordpress.lndo.site/app/uploads/2020/07/luca-bravo-VowIFDxogG4-unsplash-1024x683.jpg\" alt=\"\" data-id=\"18\" data-full-url=\"https://headless-wordpress.lndo.site/app/uploads/2020/07/luca-bravo-VowIFDxogG4-unsplash-scaled.jpg\" data-link=\"https://headless-wordpress.lndo.site/luca-bravo-vowifdxogg4-unsplash/\" class=\"wp-image-18\"/></figure></li><li class=\"blocks-gallery-item\"><figure><img src=\"https://headless-wordpress.lndo.site/app/uploads/2020/07/luca-bravo-oV4bR3YoR_s-unsplash-1024x683.jpg\" alt=\"\" data-id=\"17\" data-full-url=\"https://headless-wordpress.lndo.site/app/uploads/2020/07/luca-bravo-oV4bR3YoR_s-unsplash-scaled.jpg\" data-link=\"https://headless-wordpress.lndo.site/luca-bravo-ov4br3yor_s-unsplash/\" class=\"wp-image-17\"/></figure></li><li class=\"blocks-gallery-item\"><figure><img src=\"https://headless-wordpress.lndo.site/app/uploads/2020/07/luca-bravo-O453M2Liufs-unsplash-1024x683.jpg\" alt=\"\" data-id=\"16\" data-full-url=\"https://headless-wordpress.lndo.site/app/uploads/2020/07/luca-bravo-O453M2Liufs-unsplash-scaled.jpg\" data-link=\"https://headless-wordpress.lndo.site/luca-bravo-o453m2liufs-unsplash/\" class=\"wp-image-16\"/></figure></li><li class=\"blocks-gallery-item\"><figure><img src=\"https://headless-wordpress.lndo.site/app/uploads/2020/07/luca-bravo-hFzIoD0F_i8-unsplash-1024x640.jpg\" alt=\"\" data-id=\"15\" data-full-url=\"https://headless-wordpress.lndo.site/app/uploads/2020/07/luca-bravo-hFzIoD0F_i8-unsplash-scaled.jpg\" data-link=\"https://headless-wordpress.lndo.site/luca-bravo-hfziod0f_i8-unsplash/\" class=\"wp-image-15\"/></figure></li><li class=\"blocks-gallery-item\"><figure><img src=\"https://headless-wordpress.lndo.site/app/uploads/2020/07/luca-bravo-ESkw2ayO2As-unsplash-1024x707.jpg\" alt=\"\" data-id=\"14\" data-full-url=\"https://headless-wordpress.lndo.site/app/uploads/2020/07/luca-bravo-ESkw2ayO2As-unsplash-scaled.jpg\" data-link=\"https://headless-wordpress.lndo.site/luca-bravo-eskw2ayo2as-unsplash/\" class=\"wp-image-14\"/></figure></li></ul></figure>\n<!-- /wp:gallery -->\n\n<!-- wp:paragraph -->\n<p>Als nieuwe WordPress gebruiker kan je naar <a href=\"https://headless-wordpress.lndo.site/wp/wp-admin/\">je dashboard</a> gaan om deze pagina te verwijderen en nieuwe pagina\'s toe te voegen voor je inhoud. Veel plezier!</p>\n<!-- /wp:paragraph -->','Voorbeeld pagina','','inherit','closed','closed','','2-revision-v1','','','2020-07-17 18:33:01','2020-07-17 18:33:01','',2,'https://headless-wordpress.lndo.site/2-revision-v1/',0,'revision','',0),
	(22,1,'2020-07-17 18:33:44','2020-07-17 18:33:44','<!-- wp:paragraph -->\n<p>Dit is een voorbeeldpagina. Het is anders dan een blog bericht omdat het op één plek blijft en tevoorschijn komt in je site navigatie (in de meeste thema\'s). De meeste mensen starten met een Over pagina dat hen voorstelt aan potentiële site bezoekers. Het zou iets als dit kunnen zeggen:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image {\"id\":18,\"sizeSlug\":\"large\"} -->\n<figure class=\"wp-block-image size-large\"><img src=\"https://headless-wordpress.lndo.site/app/uploads/2020/07/luca-bravo-VowIFDxogG4-unsplash-1024x683.jpg\" alt=\"\" class=\"wp-image-18\"/></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p>Leuk hoor! Geweldig!</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>Hoi daar! Ik ben een fietskoerier in het dagelijks leven en een beginnende acteur in de avonduren. Ik leef in Los Angeles, heb een leuke hond genaamd Jack en ik hou van piña coladas. (En overvallen worden door de regen.)</p><cite>Jan de man</cite></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:heading -->\n<h2>Of zoiets als dit</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>De XYZ Doohickey Company is opgericht in 1971 en heeft sindsdien kwalitatieve   doohickeys aan het publiek geleverd. Gevestigd in Gotham City, XYZ heeft meer dan 2000 mensen in dienst en doen allemaal fantastische dingen voor de community in Gotham.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:gallery {\"ids\":[20,19,18,17,16,15,14],\"columns\":4} -->\n<figure class=\"wp-block-gallery columns-4 is-cropped\"><ul class=\"blocks-gallery-grid\"><li class=\"blocks-gallery-item\"><figure><img src=\"https://headless-wordpress.lndo.site/app/uploads/2020/07/luca-bravo-zAjdgNXsMeg-unsplash-1024x683.jpg\" alt=\"\" data-id=\"20\" data-full-url=\"https://headless-wordpress.lndo.site/app/uploads/2020/07/luca-bravo-zAjdgNXsMeg-unsplash-scaled.jpg\" data-link=\"https://headless-wordpress.lndo.site/luca-bravo-zajdgnxsmeg-unsplash/\" class=\"wp-image-20\"/></figure></li><li class=\"blocks-gallery-item\"><figure><img src=\"https://headless-wordpress.lndo.site/app/uploads/2020/07/luca-bravo-Z87YuMKEiWk-unsplash-1024x683.jpg\" alt=\"\" data-id=\"19\" data-full-url=\"https://headless-wordpress.lndo.site/app/uploads/2020/07/luca-bravo-Z87YuMKEiWk-unsplash-scaled.jpg\" data-link=\"https://headless-wordpress.lndo.site/luca-bravo-z87yumkeiwk-unsplash/\" class=\"wp-image-19\"/></figure></li><li class=\"blocks-gallery-item\"><figure><img src=\"https://headless-wordpress.lndo.site/app/uploads/2020/07/luca-bravo-VowIFDxogG4-unsplash-1024x683.jpg\" alt=\"\" data-id=\"18\" data-full-url=\"https://headless-wordpress.lndo.site/app/uploads/2020/07/luca-bravo-VowIFDxogG4-unsplash-scaled.jpg\" data-link=\"https://headless-wordpress.lndo.site/luca-bravo-vowifdxogg4-unsplash/\" class=\"wp-image-18\"/></figure></li><li class=\"blocks-gallery-item\"><figure><img src=\"https://headless-wordpress.lndo.site/app/uploads/2020/07/luca-bravo-oV4bR3YoR_s-unsplash-1024x683.jpg\" alt=\"\" data-id=\"17\" data-full-url=\"https://headless-wordpress.lndo.site/app/uploads/2020/07/luca-bravo-oV4bR3YoR_s-unsplash-scaled.jpg\" data-link=\"https://headless-wordpress.lndo.site/luca-bravo-ov4br3yor_s-unsplash/\" class=\"wp-image-17\"/></figure></li><li class=\"blocks-gallery-item\"><figure><img src=\"https://headless-wordpress.lndo.site/app/uploads/2020/07/luca-bravo-O453M2Liufs-unsplash-1024x683.jpg\" alt=\"\" data-id=\"16\" data-full-url=\"https://headless-wordpress.lndo.site/app/uploads/2020/07/luca-bravo-O453M2Liufs-unsplash-scaled.jpg\" data-link=\"https://headless-wordpress.lndo.site/luca-bravo-o453m2liufs-unsplash/\" class=\"wp-image-16\"/></figure></li><li class=\"blocks-gallery-item\"><figure><img src=\"https://headless-wordpress.lndo.site/app/uploads/2020/07/luca-bravo-hFzIoD0F_i8-unsplash-1024x640.jpg\" alt=\"\" data-id=\"15\" data-full-url=\"https://headless-wordpress.lndo.site/app/uploads/2020/07/luca-bravo-hFzIoD0F_i8-unsplash-scaled.jpg\" data-link=\"https://headless-wordpress.lndo.site/luca-bravo-hfziod0f_i8-unsplash/\" class=\"wp-image-15\"/></figure></li><li class=\"blocks-gallery-item\"><figure><img src=\"https://headless-wordpress.lndo.site/app/uploads/2020/07/luca-bravo-ESkw2ayO2As-unsplash-1024x707.jpg\" alt=\"\" data-id=\"14\" data-full-url=\"https://headless-wordpress.lndo.site/app/uploads/2020/07/luca-bravo-ESkw2ayO2As-unsplash-scaled.jpg\" data-link=\"https://headless-wordpress.lndo.site/luca-bravo-eskw2ayo2as-unsplash/\" class=\"wp-image-14\"/></figure></li></ul></figure>\n<!-- /wp:gallery -->\n\n<!-- wp:paragraph -->\n<p>Als nieuwe WordPress gebruiker kan je naar <a href=\"https://headless-wordpress.lndo.site/wp/wp-admin/\">je dashboard</a> gaan om deze pagina te verwijderen en nieuwe pagina\'s toe te voegen voor je inhoud. Veel plezier!</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading {\"level\":3} -->\n<h3>Hier nog een H3 kopje</h3>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Sed posuere consectetur est at lobortis. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Donec id elit non mi porta gravida at eget metus. Donec ullamcorper nulla non metus auctor fringilla.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><br>Nulla vitae elit libero, a pharetra augue. Integer posuere erat a ante venenatis dapibus posuere velit aliquet. Maecenas faucibus mollis interdum. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent commodo cursus magna, vel scelerisque nisl consectetur et. Donec ullamcorper nulla non metus auctor fringilla.</p>\n<!-- /wp:paragraph -->','Voorbeeld pagina','','inherit','closed','closed','','2-revision-v1','','','2020-07-17 18:33:44','2020-07-17 18:33:44','',2,'https://headless-wordpress.lndo.site/2-revision-v1/',0,'revision','',0),
	(23,1,'2020-07-17 19:21:11','2020-07-17 19:21:11','<!-- wp:paragraph -->\n<p>Dit is een voorbeeldpagina. Het is anders dan een blog bericht omdat het op één plek blijft en tevoorschijn komt in je site navigatie (in de meeste thema\'s). De meeste mensen starten met een Over pagina dat hen voorstelt aan potentiële site bezoekers. Het zou iets als dit kunnen zeggen:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image {\"id\":18,\"sizeSlug\":\"large\"} -->\n<figure class=\"wp-block-image size-large\"><img src=\"https://headless-wordpress.lndo.site/app/uploads/2020/07/luca-bravo-VowIFDxogG4-unsplash-1024x683.jpg\" alt=\"\" class=\"wp-image-18\"/></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p>Leuk hoor! Geweldig!</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>Hoi daar! Ik ben een fietskoerier in het dagelijks leven en een beginnende acteur in de avonduren. Ik leef in Los Angeles, heb een leuke hond genaamd Jack en ik hou van piña coladas. (En overvallen worden door de regen.)</p><cite>Jan de man</cite></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:heading -->\n<h2>Of zoiets als dit</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>De XYZ Doohickey Company is opgericht in 1971 en heeft sindsdien kwalitatieve   doohickeys aan het publiek geleverd. Gevestigd in Gotham City, XYZ heeft meer dan 2000 mensen in dienst en doen allemaal fantastische dingen voor de community in Gotham.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Als nieuwe WordPress gebruiker kan je naar <a href=\"https://headless-wordpress.lndo.site/wp/wp-admin/\">je dashboard</a> gaan om deze pagina te verwijderen en nieuwe pagina\'s toe te voegen voor je inhoud. Veel plezier!</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading {\"level\":3} -->\n<h3>Hier nog een H3 kopje</h3>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Sed posuere consectetur est at lobortis. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Donec id elit non mi porta gravida at eget metus. Donec ullamcorper nulla non metus auctor fringilla.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Nulla vitae elit libero, a pharetra augue. Integer posuere erat a ante venenatis dapibus posuere velit aliquet. Maecenas faucibus mollis interdum. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent commodo cursus magna, vel scelerisque nisl consectetur et. Donec ullamcorper nulla non metus auctor fringilla.</p>\n<!-- /wp:paragraph -->','Voorbeeld pagina','','inherit','closed','closed','','2-revision-v1','','','2020-07-17 19:21:11','2020-07-17 19:21:11','',2,'https://headless-wordpress.lndo.site/2-revision-v1/',0,'revision','',0),
	(24,1,'2020-07-17 20:56:36','2020-07-17 20:56:36','<!-- wp:paragraph -->\n<p>Dit is een voorbeeldpagina. Het is anders dan een blog bericht omdat het op één plek blijft en tevoorschijn komt in je site navigatie (in de meeste thema\'s). De meeste mensen starten met een Over pagina dat hen voorstelt aan potentiële site bezoekers. Het zou iets als dit kunnen zeggen:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image {\"id\":18,\"sizeSlug\":\"large\"} -->\n<figure class=\"wp-block-image size-large\"><img src=\"https://headless-wordpress.lndo.site/app/uploads/2020/07/luca-bravo-VowIFDxogG4-unsplash-1024x683.jpg\" alt=\"\" class=\"wp-image-18\"/></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p>Leuk hoor! Geweldig!</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>Hoi daar! Ik ben een fietskoerier in het dagelijks leven en een beginnende acteur in de avonduren. Ik leef in Los Angeles, heb een leuke hond genaamd Jack en ik hou van piña coladas. (En overvallen worden door de regen.)</p><cite>Jan de man</cite></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:heading -->\n<h2>Of zoiets als dit</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>De XYZ Doohickey Company is opgericht in 1971 en heeft sindsdien kwalitatieve   doohickeys aan het publiek geleverd. Gevestigd in Gotham City, XYZ heeft meer dan 2000 mensen in dienst en doen allemaal fantastische dingen voor de community in Gotham.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Als nieuwe WordPress gebruiker kan je naar <a href=\"https://headless-wordpress.lndo.site/wp/wp-admin/\">je dashboard</a> gaan om deze pagina te verwijderen en nieuwe pagina\'s toe te voegen voor je inhoud. Veel plezier!</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading {\"level\":3} -->\n<h3>Hier nog een H3 kopje</h3>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Sed posuere consectetur est at lobortis. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Donec id elit non mi porta gravida at eget metus. Donec ullamcorper nulla non metus auctor fringilla.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Nulla vitae elit libero, a pharetra augue. Integer posuere erat a ante venenatis dapibus posuere velit aliquet. Maecenas faucibus mollis interdum. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent commodo cursus magna, vel scelerisque nisl consectetur et. Donec ullamcorper nulla non metus auctor fringilla.</p>\n<!-- /wp:paragraph -->','Voorbeeld pagina','','inherit','closed','closed','','2-revision-v1','','','2020-07-17 20:56:36','2020-07-17 20:56:36','',2,'https://headless-wordpress.lndo.site/2-revision-v1/',0,'revision','',0),
	(25,1,'2020-07-17 20:58:25','2020-07-17 20:58:25','','00','','inherit','open','closed','','00','','','2020-07-17 20:58:25','2020-07-17 20:58:25','',2,'https://headless-wordpress.lndo.site/app/uploads/2020/07/00.jpg',0,'attachment','image/jpeg',0),
	(26,1,'2020-07-17 20:59:35','2020-07-17 20:59:35','<!-- wp:paragraph -->\n<p>Dit is een voorbeeldpagina. Het is anders dan een blog bericht omdat het op één plek blijft en tevoorschijn komt in je site navigatie (in de meeste thema\'s). De meeste mensen starten met een Over pagina dat hen voorstelt aan potentiële site bezoekers. Het zou iets als dit kunnen zeggen:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image {\"id\":18,\"sizeSlug\":\"large\"} -->\n<figure class=\"wp-block-image size-large\"><img src=\"https://headless-wordpress.lndo.site/app/uploads/2020/07/luca-bravo-VowIFDxogG4-unsplash-1024x683.jpg\" alt=\"\" class=\"wp-image-18\"/></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p>Leuk hoor! Geweldig!</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>Hoi daar! Ik ben een fietskoerier in het dagelijks leven en een beginnende acteur in de avonduren. Ik leef in Los Angeles, heb een leuke hond genaamd Jack en ik hou van piña coladas. (En overvallen worden door de regen.)</p><cite>Jan de man</cite></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:heading -->\n<h2>Of zoiets als dit</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>De XYZ Doohickey Company is opgericht in 1971 en heeft sindsdien kwalitatieve   doohickeys aan het publiek geleverd. Gevestigd in Gotham City, XYZ heeft meer dan 2000 mensen in dienst en doen allemaal fantastische dingen voor de community in Gotham.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Als nieuwe WordPress gebruiker kan je naar <a href=\"https://headless-wordpress.lndo.site/wp/wp-admin/\">je dashboard</a> gaan om deze pagina te verwijderen en nieuwe pagina\'s toe te voegen voor je inhoud. Veel plezier!</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading {\"level\":3} -->\n<h3>Hier nog een H3 kopje</h3>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Sed posuere consectetur est at lobortis. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Donec id elit non mi porta gravida at eget metus. Donec ullamcorper nulla non metus auctor fringilla.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Nulla vitae elit libero, a pharetra augue. Integer posuere erat a ante venenatis dapibus posuere velit aliquet. Maecenas faucibus mollis interdum. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent commodo cursus magna, vel scelerisque nisl consectetur et. Donec ullamcorper nulla non metus auctor fringilla.</p>\n<!-- /wp:paragraph -->','Voorbeeld pagina','','inherit','closed','closed','','2-revision-v1','','','2020-07-17 20:59:35','2020-07-17 20:59:35','',2,'https://headless-wordpress.lndo.site/2-revision-v1/',0,'revision','',0),
	(27,1,'2020-07-20 14:47:35','2020-07-20 14:47:35','<!-- wp:paragraph -->\n<p>Dit is een voorbeeldpagina. Het is anders dan een blog bericht omdat het op één plek blijft en tevoorschijn komt in je site navigatie (in de meeste thema\'s). De meeste mensen starten met een Over pagina dat hen voorstelt aan potentiële site bezoekers. Het zou iets als dit kunnen zeggen:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image {\"id\":18,\"sizeSlug\":\"large\"} -->\n<figure class=\"wp-block-image size-large\"><img src=\"https://headless-wordpress.lndo.site/app/uploads/2020/07/luca-bravo-VowIFDxogG4-unsplash-1024x683.jpg\" alt=\"\" class=\"wp-image-18\"/></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p>Leuk hoor! Geweldig!</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>Hoi daar! Ik ben een fietskoerier in het dagelijks leven en een beginnende acteur in de avonduren. Ik leef in Los Angeles, heb een leuke hond genaamd Jack en ik hou van piña coladas. (En overvallen worden door de regen.)</p><cite>Jan de man</cite></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:heading -->\n<h2>Of zoiets als dit</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>De XYZ Doohickey Company is opgericht in 1971 en heeft sindsdien kwalitatieve   doohickeys aan het publiek geleverd. Gevestigd in Gotham City, XYZ heeft meer dan 2000 mensen in dienst en doen allemaal fantastische dingen voor de community in Gotham.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Als nieuwe WordPress gebruiker kan je naar <a href=\"https://headless-wordpress.lndo.site/wp/wp-admin/\">je dashboard</a> gaan om deze pagina te verwijderen en nieuwe pagina\'s toe te voegen voor je inhoud. Veel plezier!</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading {\"level\":3} -->\n<h3>Hier nog een H3 kopje</h3>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Sed posuere consectetur est at lobortis. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Donec id elit non mi porta gravida at eget metus. Donec ullamcorper nulla non metus auctor fringilla.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Nulla vitae elit libero, a pharetra augue. Integer posuere erat a ante venenatis dapibus posuere velit aliquet. Maecenas faucibus mollis interdum. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent commodo cursus magna, vel scelerisque nisl consectetur et. Donec ullamcorper nulla non metus auctor fringilla.</p>\n<!-- /wp:paragraph -->','Voorbeeld pagina','','inherit','closed','closed','','2-revision-v1','','','2020-07-20 14:47:35','2020-07-20 14:47:35','',2,'https://headless-wordpress.lndo.site/2-revision-v1/',0,'revision','',0),
	(30,1,'2020-07-20 19:34:31','2020-07-20 19:34:31','<!-- wp:paragraph -->\n<p>Dit is een voorbeeldpagina. Het is anders dan een blog bericht omdat het op één plek blijft en tevoorschijn komt in je site navigatie (in de meeste thema\'s). De meeste mensen starten met een Over pagina dat hen voorstelt aan potentiële site bezoekers. Het zou iets als dit kunnen zeggen:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:buttons -->\n<div class=\"wp-block-buttons\"><!-- wp:button -->\n<div class=\"wp-block-button\"><a class=\"wp-block-button__link\" href=\"https://headless-wordpress.lndo.site/privacybeleid/\">Ik vind er iets van</a></div>\n<!-- /wp:button --></div>\n<!-- /wp:buttons -->\n\n<!-- wp:image {\"id\":18,\"sizeSlug\":\"large\"} -->\n<figure class=\"wp-block-image size-large\"><img src=\"https://headless-wordpress.lndo.site/app/uploads/2020/07/luca-bravo-VowIFDxogG4-unsplash-1024x683.jpg\" alt=\"\" class=\"wp-image-18\"/></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p>Leuk hoor! Geweldig!</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>Hoi daar! Ik ben een fietskoerier in het dagelijks leven en een beginnende acteur in de avonduren. Ik leef in Los Angeles, heb een leuke hond genaamd Jack en ik hou van piña coladas. (En overvallen worden door de regen.)</p><cite>Jan de man</cite></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:heading -->\n<h2>Of zoiets als dit</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>De XYZ Doohickey Company is opgericht in 1971 en heeft sindsdien kwalitatieve   doohickeys aan het publiek geleverd. Gevestigd in Gotham City, XYZ heeft meer dan 2000 mensen in dienst en doen allemaal fantastische dingen voor de community in Gotham.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Als nieuwe WordPress gebruiker kan je naar <a href=\"https://headless-wordpress.lndo.site/wp/wp-admin/\">je dashboard</a> gaan om deze pagina te verwijderen en nieuwe pagina\'s toe te voegen voor je inhoud. Veel plezier!</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading {\"level\":3} -->\n<h3>Hier nog een H3 kopje</h3>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Sed posuere consectetur est at lobortis. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Donec id elit non mi porta gravida at eget metus. Donec ullamcorper nulla non metus auctor fringilla.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Nulla vitae elit libero, a pharetra augue. Integer posuere erat a ante venenatis dapibus posuere velit aliquet. Maecenas faucibus mollis interdum. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent commodo cursus magna, vel scelerisque nisl consectetur et. Donec ullamcorper nulla non metus auctor fringilla.</p>\n<!-- /wp:paragraph -->','Voorbeeld pagina','','inherit','closed','closed','','2-revision-v1','','','2020-07-20 19:34:31','2020-07-20 19:34:31','',2,'https://headless-wordpress.lndo.site/2-revision-v1/',0,'revision','',0),
	(32,1,'2020-07-21 12:08:10','2020-07-21 12:08:10','<!-- wp:paragraph -->\n<p>Ik ben een kindpagina. Aenean eu leo quam. Pellentesque ornare sem lacinia quam venenatis vestibulum. Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auctor. Maecenas faucibus mollis interdum. Aenean lacinia bibendum nulla sed consectetur.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><br>Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Praesent commodo cursus magna, vel scelerisque nisl consectetur et. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Nullam id dolor id nibh ultricies vehicula ut id elit. Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auctor. Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auctor. Donec sed odio dui.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><br>Integer posuere erat a ante venenatis dapibus posuere velit aliquet. Nulla vitae elit libero, a pharetra augue. Aenean lacinia bibendum nulla sed consectetur. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><br>Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec id elit non mi porta gravida at eget metus. Cras mattis consectetur purus sit amet fermentum.</p>\n<!-- /wp:paragraph -->','Child page','','publish','closed','closed','','child-page','','','2020-07-21 12:16:30','2020-07-21 12:16:30','',0,'https://headless-wordpress.lndo.site/?page_id=32',0,'page','',0),
	(33,1,'2020-07-21 12:08:10','2020-07-21 12:08:10','<!-- wp:paragraph -->\n<p>Ik ben een kindpagina. Aenean eu leo quam. Pellentesque ornare sem lacinia quam venenatis vestibulum. Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auctor. Maecenas faucibus mollis interdum. Aenean lacinia bibendum nulla sed consectetur.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><br>Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Praesent commodo cursus magna, vel scelerisque nisl consectetur et. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Nullam id dolor id nibh ultricies vehicula ut id elit. Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auctor. Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auctor. Donec sed odio dui.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><br>Integer posuere erat a ante venenatis dapibus posuere velit aliquet. Nulla vitae elit libero, a pharetra augue. Aenean lacinia bibendum nulla sed consectetur. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><br>Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec id elit non mi porta gravida at eget metus. Cras mattis consectetur purus sit amet fermentum.</p>\n<!-- /wp:paragraph -->','Child page','','inherit','closed','closed','','32-revision-v1','','','2020-07-21 12:08:10','2020-07-21 12:08:10','',32,'https://headless-wordpress.lndo.site/32-revision-v1/',0,'revision','',0),
	(34,1,'2020-07-21 12:29:15','2020-07-21 12:29:15',' ','','','publish','closed','closed','','34','','','2020-07-22 14:53:42','2020-07-22 14:53:42','',0,'https://headless-wordpress.lndo.site/?p=34',3,'nav_menu_item','',0),
	(35,1,'2020-07-21 12:29:15','2020-07-21 12:29:15',' ','','','publish','closed','closed','','35','','','2020-07-22 14:53:42','2020-07-22 14:53:42','',0,'https://headless-wordpress.lndo.site/?p=35',2,'nav_menu_item','',0),
	(36,1,'2020-07-21 12:29:15','2020-07-21 12:29:15','','Home','','publish','closed','closed','','home','','','2020-07-22 14:53:42','2020-07-22 14:53:42','',0,'https://headless-wordpress.lndo.site/?p=36',1,'nav_menu_item','',0),
	(37,1,'2020-07-21 12:29:16','2020-07-21 12:29:16',' ','','','publish','closed','closed','','37','','','2020-07-22 14:53:42','2020-07-22 14:53:42','',0,'https://headless-wordpress.lndo.site/?p=37',6,'nav_menu_item','',0),
	(38,1,'2020-07-21 12:29:16','2020-07-21 12:29:16',' ','','','publish','closed','closed','','38','','','2020-07-22 14:53:42','2020-07-22 14:53:42','',0,'https://headless-wordpress.lndo.site/?p=38',4,'nav_menu_item','',0),
	(39,1,'2020-07-21 12:29:16','2020-07-21 12:29:16',' ','','','publish','closed','closed','','39','','','2020-07-22 14:53:42','2020-07-22 14:53:42','',0,'https://headless-wordpress.lndo.site/?p=39',7,'nav_menu_item','',0),
	(40,1,'2020-07-21 12:29:16','2020-07-21 12:29:16',' ','','','publish','closed','closed','','40','','','2020-07-22 14:53:42','2020-07-22 14:53:42','',0,'https://headless-wordpress.lndo.site/?p=40',5,'nav_menu_item','',0),
	(41,1,'2020-07-21 12:29:38','2020-07-21 12:29:38',' ','','','publish','closed','closed','','41','','','2020-07-21 12:29:38','2020-07-21 12:29:38','',0,'https://headless-wordpress.lndo.site/?p=41',2,'nav_menu_item','',0),
	(42,1,'2020-07-21 12:29:38','2020-07-21 12:29:38','','Home','','publish','closed','closed','','home-2','','','2020-07-21 12:29:38','2020-07-21 12:29:38','',0,'https://headless-wordpress.lndo.site/?p=42',1,'nav_menu_item','',0),
	(43,1,'2020-07-22 11:24:13','2020-07-22 11:24:13','','Trendwerk.nl','','publish','closed','closed','','trendwerk-nl','','','2020-07-22 14:53:42','2020-07-22 14:53:42','',0,'https://headless-wordpress.lndo.site/?p=43',8,'nav_menu_item','',0);

/*!40000 ALTER TABLE `wp_posts` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table wp_term_relationships
# ------------------------------------------------------------

DROP TABLE IF EXISTS `wp_term_relationships`;

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

LOCK TABLES `wp_term_relationships` WRITE;
/*!40000 ALTER TABLE `wp_term_relationships` DISABLE KEYS */;

INSERT INTO `wp_term_relationships` (`object_id`, `term_taxonomy_id`, `term_order`)
VALUES
	(1,1,0),
	(8,1,0),
	(34,2,0),
	(35,2,0),
	(36,2,0),
	(37,2,0),
	(38,2,0),
	(39,2,0),
	(40,2,0),
	(41,3,0),
	(42,3,0),
	(43,2,0);

/*!40000 ALTER TABLE `wp_term_relationships` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table wp_term_taxonomy
# ------------------------------------------------------------

DROP TABLE IF EXISTS `wp_term_taxonomy`;

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

LOCK TABLES `wp_term_taxonomy` WRITE;
/*!40000 ALTER TABLE `wp_term_taxonomy` DISABLE KEYS */;

INSERT INTO `wp_term_taxonomy` (`term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`)
VALUES
	(1,1,'category','',0,2),
	(2,2,'nav_menu','',0,8),
	(3,3,'nav_menu','',0,2);

/*!40000 ALTER TABLE `wp_term_taxonomy` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table wp_termmeta
# ------------------------------------------------------------

DROP TABLE IF EXISTS `wp_termmeta`;

CREATE TABLE `wp_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



# Dump of table wp_terms
# ------------------------------------------------------------

DROP TABLE IF EXISTS `wp_terms`;

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

LOCK TABLES `wp_terms` WRITE;
/*!40000 ALTER TABLE `wp_terms` DISABLE KEYS */;

INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`)
VALUES
	(1,'Geen categorie','geen-categorie',0),
	(2,'Hoofdmenutje','hoofdmenutje',0),
	(3,'Footer menu hoor','footer-menu-hoor',0);

/*!40000 ALTER TABLE `wp_terms` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table wp_usermeta
# ------------------------------------------------------------

DROP TABLE IF EXISTS `wp_usermeta`;

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

LOCK TABLES `wp_usermeta` WRITE;
/*!40000 ALTER TABLE `wp_usermeta` DISABLE KEYS */;

INSERT INTO `wp_usermeta` (`umeta_id`, `user_id`, `meta_key`, `meta_value`)
VALUES
	(1,1,'nickname','trendwerk'),
	(2,1,'first_name',''),
	(3,1,'last_name',''),
	(4,1,'description',''),
	(5,1,'rich_editing','true'),
	(6,1,'syntax_highlighting','true'),
	(7,1,'comment_shortcuts','false'),
	(8,1,'admin_color','fresh'),
	(9,1,'use_ssl','0'),
	(10,1,'show_admin_bar_front','true'),
	(11,1,'locale',''),
	(12,1,'wp_capabilities','a:1:{s:13:\"administrator\";b:1;}'),
	(13,1,'wp_user_level','10'),
	(14,1,'dismissed_wp_pointers',''),
	(15,1,'show_welcome_panel','0'),
	(16,1,'session_tokens','a:1:{s:64:\"b1c90dfd59243dd4fb6d6a8688ea8ee22d71e3718ec62829230186f57955c4a4\";a:4:{s:10:\"expiration\";i:1595592991;s:2:\"ip\";s:10:\"172.20.0.2\";s:2:\"ua\";s:120:\"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.89 Safari/537.36\";s:5:\"login\";i:1595420191;}}'),
	(17,1,'wp_dashboard_quick_press_last_post_id','4'),
	(18,1,'community-events-location','a:1:{s:2:\"ip\";s:10:\"172.20.0.0\";}'),
	(19,1,'closedpostboxes_dashboard','a:1:{i:0;s:21:\"dashboard_quick_press\";}'),
	(20,1,'metaboxhidden_dashboard','a:0:{}'),
	(21,1,'wp_user-settings','libraryContent=browse'),
	(22,1,'wp_user-settings-time','1595010777'),
	(23,1,'managenav-menuscolumnshidden','a:5:{i:0;s:11:\"link-target\";i:1;s:11:\"css-classes\";i:2;s:3:\"xfn\";i:3;s:11:\"description\";i:4;s:15:\"title-attribute\";}'),
	(24,1,'metaboxhidden_nav-menus','a:1:{i:0;s:12:\"add-post_tag\";}'),
	(25,1,'nav_menu_recently_edited','2');

/*!40000 ALTER TABLE `wp_usermeta` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table wp_users
# ------------------------------------------------------------

DROP TABLE IF EXISTS `wp_users`;

CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

LOCK TABLES `wp_users` WRITE;
/*!40000 ALTER TABLE `wp_users` DISABLE KEYS */;

INSERT INTO `wp_users` (`ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`)
VALUES
	(1,'trendwerk','$2y$10$KO.9.p4.g0zDP.NdSbxyeOzATPxAaNQ1Ol/6SLQFJ0YHZd8m6mv7i','trendwerk','hallo@trendwerk.nl','https://headless-wordpress.lndo.site/wp','2020-07-15 12:04:58','',0,'trendwerk');

/*!40000 ALTER TABLE `wp_users` ENABLE KEYS */;
UNLOCK TABLES;



/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
